<?php
class Home extends CI_Controller
{
	 function __construct()
	 {
		 parent::__construct();
		 $this->load->model(['ModelUser','ModelKomentar','ModelSeminar','home_model']);
	 }
	 public function index()
	{
	 $data = [
		 'judul' => "BACOD",
		 
			];

	 //jika sudah login dan jika belum login
	 
	 if ($this->session->userdata('email')) {
	 $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
	 $data['event']=$this->model_barang->getevent()->result();
    $data['news']=$this->model_barang->getnews()->result();
	 $data['user'] = $user['nama'];
	
	 $this->load->view('home/header', $data);
	 $this->load->view('home/h-participant', $data);
	 $this->load->view('home/modal');
	 $this->load->view('home/footer', $data);

	} else {
	 
	 $data['user'] = 'Pengunjung';
	 
	 
	$this->load->view('home/header', $data);
	$this->load->view('home/h-pengunjung', $data);
	$this->load->view('home/modal');
	$this->load->view('home/footer', $data);
	}}

//......................................................................//

  public function detailevent() 
        {

	 $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array(); 
        $id = $this->uri->segment(3); 
        $event = $this->model_barang->joinKategorievent(['event.id' => $id])->result(); 
        $data['user'] = $user['nama']; 
        $data['title'] = "Detail event"; 
        
        foreach ($event as $event) 
            { 
            $data['judul'] = $event->judul_event; 
            $data['keterangan'] = $event->keterangan; 
             
            $data['kategori'] = $event->kategori; 
             
            $data['harga'] = $event->harga; 
            $data['image'] = $event->image; 
            $data['dipesan'] = $event->dipesan; 
            $data['dibeli'] = $event->dibeli; 
            $data['stok'] = $event->stok; 
            $data['id'] = $id; 
            } 
        $this->load->view('home/header', $data);
        $this->load->view('home/detail-event', $data); 
        $this->load->view('home/modal'); 
        $this->load->view('home/footer'); 
        }
//...................................................................................................//
    public function tambahBooking() 
        { 
        $id_event = $this->uri->segment(3); 
        //memilih data event yang untuk dimasukkan ke tabel temp/keranjang melalui variabel $isi 
        $d = $this->db->query("Select*from event where id='$id_event'")->row(); 
        //berupa data2 yang akan disimpan ke dalam tabel temp/keranjang 
        $isi = [ 
                'id_event' => $id_event, 
                'judul_event' => $d->judul_event, 
                'id_user' => $this->session->userdata('id_user'), 
                'email_user' => $this->session->userdata('email'), 
                'tgl_booking' => date('Y-m-d H:i:s'), 
                'image' => $d->image, 
                'penulis' => $d->pengarang, 
                'penerbit' => $d->penerbit, 
                'tahun_terbit' => $d->tahun_terbit 
                ]; 
        //cek apakah event yang di klik booking sudah ada di keranjang
        $temp = $this->ModelBooking->getDataWhere('temp', ['id_event' => $id_event])->num_rows(); 
        $userid = $this->session->userdata('id_user'); 
        //cek jika sudah memasukan 3 event untuk dibooking dalam keranjang 
        $tempuser = $this->db->query("select*from temp where id_user ='$userid'")->num_rows(); 
        //cek jika masih ada booking event yang belum diambil 
        $databooking = $this->db->query("select*from booking where id_user='$userid'")->num_rows(); 
        if ($databooking > 0) 
            { 
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-message" role="alert">Masih Ada booking event sebelumnya yang belum diambil.<br> Ambil event yang dibooking atau tunggu 1x24 Jam untuk bisa booking kembali </div>'); 
redirect(base_url()); 
            } 
        //jika event yang diklik booking sudah ada di keranjang 
        if ($temp > 0) 
            { 
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-message" role="alert">event ini Sudah anda booking </div>'); 
            redirect(base_url() . 'home'); 
            } 
        //jika event yang akan dibooking sudah mencapai 3 item 
        if ($tempuser == 3) 
            { 
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-message" role="alert">Booking event Tidak Boleh Lebih dari 3</div>'); 
            redirect(base_url() . 'home'); 
            } 
        //membuat tabel temp jika belum ada 
        $this->ModelBooking->createTemp(); 
        $this->ModelBooking->insertData('temp', $isi); 
        //pesan ketika berhasil memasukkan event ke keranjang 
        $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-message" role="alert">event berhasil ditambahkan ke keranjang </div>'); 
        redirect(base_url() . 'home'); 
        }

//......................................................................//

  public function detailnews() 
        {

     $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array(); 
        $id = $this->uri->segment(3); 
        $event = $this->model_barang->joinKategorinews(['news.id' => $id])->result(); 
        $data['user'] = $user['nama']; 
        $data['title'] = "Detail News"; 
        
        foreach ($news as $news) 
            { 
            $data['judul_news'] = $news->judul_news; 
            $data['keterangan'] = $news->keterangan; 
             
            $data['kategori'] = $news->kategori; 
             
          
            $data['image'] = $news->image; 
           
            $data['id'] = $id; 
            } 
        $this->load->view('home/header', $data);
        $this->load->view('home/detail-news', $data); 
        $this->load->view('home/modal'); 
        $this->load->view('home/footer'); 
        }
//......................................................................//
public function tentang_kami(){
      
      $data['tentangkami']      = $this->home_model->Gettentangkami();

     //jika sudah login dan jika belum login
     
     if ($this->session->userdata('email')) {
     $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
     $data['event']=$this->model_barang->getevent()->result();
     $data['user'] = $user['nama'];
    
     $this->load->view('home/header', $data);
     $this->load->view('home/tentang_kami.php', $data);
     
     $this->load->view('home/modal');
     $this->load->view('home/footer', $data);

    } else {
     
     $data['user'] = 'Pengunjung';
     
     
    $this->load->view('home/header', $data);
    $this->load->view('home/tentang_kami.php', $data);
   
    $this->load->view('home/modal');
    $this->load->view('home/footer', $data);
    }}
        
//......................................................................//

public function cara_pesan() {
       
      
        $data['carapesan']      = $this->home_model->Getcarapesan();
      
        
    if ($this->session->userdata('email')) {
     $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
     $data['event']=$this->model_barang->getevent()->result();
     $data['user'] = $user['nama'];
    
     $this->load->view('home/header', $data);
     $this->load->view('home/cara_pesan.php', $data);
     $this->load->view('home/modal');
     $this->load->view('home/footer', $data);

    } else {
     
     $data['user'] = 'Pengunjung';
     
     
    $this->load->view('home/header', $data);
    $this->load->view('home/cara_pesan.php', $data);
    $this->load->view('home/modal');
    $this->load->view('home/footer', $data);
    }}
//...................................................................................................//
    public function keranjang() {

    $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
     $data['event']=$this->model_barang->getevent()->result();
     $data['user'] = $user['nama'];
        $data['bank']           = $this->home_model->GetBank(); 
        $data['kategori']       = $this->model_barang->GetKategori(); 

        $id_produk = $this->uri->segment(3);

        if ($id_produk!="") {

            $query  = $this->home_model->GeteventId($id);

            foreach ($query->result_array() as $value) {

                $id = $value['id'];
               
                $harga = $value['harga'];   
                $judul_event = $value['judul_event'];   
                $stok   = 1;
                
            }

            $masuk = array(
                'id'      => $id,
                'qty'     => $stok,
                'price'   => $harga,
                'name'    => $judul_event);
            $this->cart->insert($masuk);

        }
        else {

        }
        
        
        $this->load->view('home/header', $data);
     $this->load->view('home/keranjang.php', $data);
     $this->load->view('home/modal');
     $this->load->view('home/footer', $data);
    }

    public function keranjang_hapus($kode) {

        $data = array(
            'rowid' => $kode,
            'qty'   => 0);
            $this->cart->update($data);
        redirect('home/keranjang');

    }

    public function keranjang_update() {
        $total = $this->cart->total_items();
        $item = $this->input->post('rowid');
        $qty = $this->input->post('qty');
        for($i=0;$i < $total;$i++)
        {
            $data = array(
            'rowid' => $item[$i],
            'qty'   => $qty[$i]);
            $this->cart->update($data);
        }
        redirect('home/keranjang');
    }
//...................................................................................................//
    public function checkout () {

        $data['logo']           = $this->home_model->GetLogo();
        $data['kontak']         = $this->home_model->GetKontak();
        $data['sosial_media']   = $this->home_model->GetSosialMedia();
        $data['seo']            = $this->home_model->GetSeo(); 
        $data['bank']           = $this->home_model->GetBank(); 
        $data['kategori']       = $this->home_model->GetKategori(); 
        $data['jasapengiriman'] = $this->home_model->GetJasaPengiriman();

        $this->load->view('home/checkout',$data);

    }

    public function checkout_hapus($kode) {

        $data = array(
            'rowid' => $kode,
            'qty'   => 0);
            $this->cart->update($data);
        redirect('home/checkout');

    }

    public function checkout_update() {
        $total = $this->cart->total_items();
        $item = $this->input->post('rowid');
        $qty = $this->input->post('qty');
        for($i=0;$i < $total;$i++)
        {
            $data = array(
            'rowid' => $item[$i],
            'qty'   => $qty[$i]);
            $this->cart->update($data);
        }
        redirect('home/checkout');
    }

    public function checkout_invoice () {

        $this->form_validation->set_rules('penerima','Nama Penerima','required');
        $this->form_validation->set_rules('email','Email','required');
        $this->form_validation->set_rules('alamat','Alamat','required');
        $this->form_validation->set_rules('no_telepon','No Telp','required');
        $this->form_validation->set_rules('propinsi','Propinsi','required');
        $this->form_validation->set_rules('kota','Kota','required');
        $this->form_validation->set_rules('kode_pos','Kode Pos','required');
        $this->form_validation->set_rules('bank_id','Bank','required');
        $this->form_validation->set_rules('jasapengiriman_id','Jasa Pengiriman','required');

        if ($this->form_validation->run()==FALSE) {

                $data['logo']           = $this->home_model->GetLogo();
                $data['kontak']         = $this->home_model->GetKontak();
                $data['sosial_media']   = $this->home_model->GetSosialMedia();
                $data['seo']            = $this->home_model->GetSeo(); 
                $data['bank']           = $this->home_model->GetBank(); 
                $data['kategori']       = $this->home_model->GetKategori(); 
                $data['jasapengiriman'] = $this->home_model->GetJasaPengiriman();

            $this->load->view('home/checkout',$data);

        }
        else {

            $tgl_skr = date('Ymd');
            $cek_kode = $this->home_model->cek_kode($tgl_skr);
            $kode_trans = "";
            foreach($cek_kode->result() as $ck)
            {
                if($ck->kd==NULL)
                {
                    $kode_trans = $tgl_skr.'001';
                }
                else
                {
                    $kd_lama = $ck->kd;
                    $kode_trans = $kd_lama+1;
                }
            }

            $penerima           = $this->input->post("penerima");
            $email              = $this->input->post("email");
            $alamat             = $this->input->post("alamat");
            $no_telepon         = $this->input->post("no_telepon");
            $propinsi           = $this->input->post("propinsi");
            $kota               = $this->input->post("kota");
            $kode_pos           = $this->input->post("kode_pos");
            $bank_id            = $this->input->post("bank_id");
            $jasapengiriman_id  = $this->input->post("jasapengiriman_id");

            $isi_psn ='<table style="border:1px solid #000;" border="1" cellpadding=0>';
                    $isi_psn ='<tr><td>Kode Produk</td><td>Nama Produk</td><td>Harga</td><td>Jumlah</td><td>Subtotal</td></tr>';
                    foreach($this->cart->contents() as $items)
                    {
$isi_psn = '<tr><td>'.$items["id"].'</td><td>'.$items["name"].'</td><td>Rp.'.$this->cart->format_number($items["price"]).'</td><td>'.$items["qty"].'</td><td>Rp.'.$this->cart->format_number($items["subtotal"]).'</td></tr>
';
                    }
                    $isi_psn = '<tr><td>Total Belanja (belum biaya kirim): </td><td colspan=4>Rp.'.$this->cart->format_number($this->cart->total()).'</td></tr>
';
                    $isi_psn ='</table><br>';
                    $isi_psn ='Harga di atas belum termasuk biaya kirim. Kami akan mengirimkan total yang harus anda bayar ke email anda dalam jangka waktu 1x24 jam.<br>';
                    $isi_psn ='Salam, Adriano MX Online Shop';


                    $this->load->library('email');
                    $this->email->set_mailtype('html');
                    $this->email->from("adrianomxshoponlin@gmail.com", "Admin Adriano MX Online Shop");
                    $this->email->to($email);
                    $this->email->subject('Detail Pesanan/Belanja Adriano MX Online Shop');
                    $this->email->message($isi_psn);
                    $this->email->send();

            $this->home_model->InsertTransaksiHeader($kode_trans,$penerima,$email,$alamat,$no_telepon,$propinsi,$kota,$kode_pos,$bank_id,$jasapengiriman_id);
            foreach($this->cart->contents() as $items)
                        {
                            $this->home_model->simpan_pesanan("insert into tbl_transaksi_detail (kode_transaksi,kode_produk,nama_produk,harga,jumlah) values('".$kode_trans."','".$items['id']."','".$items['name']."','".$items['price']."','".$items['qty']."')");
                            // $this->home_model->update_dibeli($items['id'],$items['qty']);
                        }
                        $this->cart->destroy();
                        ?>
                        <script type="text/javascript">
                        alert("Pesanan anda telah terkirim, kami akan segera memprosesnya dalam waktu 1x24 jam. Silahkan cek email anda beberapa saat lagi untuk melihat rincian detail pembayaran.\n Terima Kasih");           
                        </script>
                        <?php
                        echo "<meta http-equiv='refresh' content='0; url=".base_url()."home/'>";

        }
    }
    
}

