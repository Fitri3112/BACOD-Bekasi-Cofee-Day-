<?php
/**
 * 
 */
class Home_admin extends CI_Controller
{
	
 public function __construct() {
        parent::__construct();
        $this->load->model('ModelUser');
    }

    public function index() {
        $this->load->view('ad/aute_header');
        $this->load->view('ad/login');
        $this->load->view('ad/aute_footer');
    }

    public function login() {

        $this->form_validation->set_rules('username','Username','required');
        $this->form_validation->set_rules('password','Password','required');

        if ($this->form_validation->run()==FALSE) {

       
        $this->load->view('ad/aute_header', $data);
        $this->load->view('ad/login',$data);
        $this->load->view('ad/aute_footer');
    
        }
        else {

            $username= $this->input->post('username');
            $password = md5($this->input->post('password'));

            $this->ModelUser->CekAdminLogin($username,$password);

        }
    }

    public function home() {

        if($this->session->userdata("logged_in")!=="") {
            $this->template->load('template','adminweb/home');
        }
        else{
            redirect('home_admin');

        }
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect("home_admin");
    } 

//manajemen event
    public function Event() 
    {
        $data['judul'] = 'Data event';
        
        $data['event'] = $this->model_barang->getevent()->result_array();
        $data['kategori'] = $this->model_barang->getKategori()->result_array();

        $this->form_validation->set_rules('judul_event', 'Judul event', 'required|min_length[3]', [
            'required' => 'Judul event harus diisi',
            'min_length' => 'Judul event terlalu pendek'
        ]);
        $this->form_validation->set_rules('id_kategori', 'Kategori', 'required', [
            'required' => 'Nama keterangan harus diisi',
        ]);
        $this->form_validation->set_rules('keterangan', 'Nama keterangan', 'required|min_length[3]', [
            'required' => 'Nama keterangan harus diisi',
            'min_length' => 'Nama keterangan terlalu pendek'
        ]);
         $this->form_validation->set_rules('harga', 'harga', 'required|numeric', [
            'required' => 'Harga harus diisi',
            'numeric' => 'Yang anda masukan bukan angka'
        ]);
        $this->form_validation->set_rules('stok', 'Stok', 'required|numeric', [
            'required' => 'Stok harus diisi',
            'numeric' => 'Yang anda masukan bukan angka'
        ]);

        //konfigurasi sebelum gambar diupload
        $config['upload_path'] = './assets/img/upload/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = '3000';
        $config['max_width'] = '1024';
        $config['max_height'] = '1000';
        $config['file_name'] = 'img' . time();

        $this->load->library('upload', $config);

        if ($this->form_validation->run() == false) {
            $this->load->view('ad/header', $data);
            $this->load->view('ad/sidebar', $data);
            $this->load->view('ad/topbar', $data);
            $this->load->view('ad/event', $data);
            $this->load->view('ad/footer');
        } else {
            if ($this->upload->do_upload('image')) {
                $image = $this->upload->data();
                $gambar = $image['file_name'];
            } else {
                $gambar = '';
            }

            $data = [
                'judul_event' => $this->input->post('judul_event', true),
                'id_kategori' => $this->input->post('id_kategori', true),
                'keterangan' => $this->input->post('keterangan', true),
                'harga' => $this->input->post('harga', true),
                'stok' => $this->input->post('stok', true),
                'dipesan' => 0,
                'dibeli' => 0,
                'image' => $gambar
            ];

            $this->model_barang->simpanevent($data);
            redirect('home_admin/event');
        }
    }
//...................................................................................................//
    public function hapusevent()
    {
        $where = ['id' => $this->uri->segment(3)];
        $this->model_barang->hapusevent($where);
        redirect('home_admin/event');
    }
//...................................................................................................//
    public function ubahevent()
    {
        $data['judul'] = 'Ubah Data event';
        
        $data['event'] = $this->model_barang->eventWhere(['id' => $this->uri->segment(3)])->result_array();
        $kategori = $this->model_barang->joinKategorievent(['event.id' => $this->uri->segment(3)])->result_array();
        foreach ($kategori as $k) {
            $data['id'] = $k['id_kategori'];
            $data['k'] = $k['kategori'];
        }
        $data['kategori'] = $this->model_barang->getKategori()->result_array();

        $this->form_validation->set_rules('judul_event', 'Judul event', 'required|min_length[3]', [
            'required' => 'Judul event harus diisi',
            'min_length' => 'Judul event terlalu pendek'
        ]);
        $this->form_validation->set_rules('id_kategori', 'Kategori', 'required', [
            'required' => 'Nama keterangan harus diisi',
        ]);
        $this->form_validation->set_rules('keterangan', 'Nama keterangan', 'required|min_length[3]', [
            'required' => 'Nama keterangan harus diisi',
            'min_length' => 'Nama keterangan terlalu pendek'
        ]);
        
        $this->form_validation->set_rules('harga', 'Nomor harga', 'required|min_length[3]|numeric', [
            'required' => 'Nama harga harus diisi',
           
            'numeric' => 'Yang anda masukan bukan angka'
        ]);
        $this->form_validation->set_rules('stok', 'Stok', 'required|numeric', [
            'required' => 'Stok harus diisi',
            'numeric' => 'Yang anda masukan bukan angka'
        ]);

        //konfigurasi sebelum gambar diupload
        $config['upload_path'] = './assets/img/upload/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = '3000';
        $config['max_width'] = '1024';
        $config['max_height'] = '1000';
        $config['file_name'] = 'img' . time();

        //memuat atau memanggil library upload
        $this->load->library('upload', $config);

        if ($this->form_validation->run() == false) {
            $this->load->view('ad/header', $data);
            $this->load->view('ad/sidebar', $data);
            $this->load->view('ad/topbar', $data);
            $this->load->view('ad/ubah_event', $data);
            $this->load->view('ad/footer');
        } else {
            if ($this->upload->do_upload('image')) {
                $image = $this->upload->data();
                unlink('assets/img/upload/' . $this->input->post('old_pict', TRUE));
                $gambar = $image['file_name'];
            } else {
                $gambar = $this->input->post('old_pict', TRUE);
            }

            $data = [
                'judul_event' => $this->input->post('judul_event', true),
                'id_kategori' => $this->input->post('id_kategori', true),
                'keterangan' => $this->input->post('keterangan', true),
                
                'harga' => $this->input->post('harga', true),
                'stok' => $this->input->post('stok', true),
                'image' => $gambar
            ];

            $this->model_barang->updateevent($data, ['id' => $this->input->post('id')]);
            redirect('home_admin/event');
        }
    }

//...................................................................................................//
	public function kategori()
    {
        $data['judul'] = 'Kategori Event';
       
        $data['kategori'] = $this->model_barang->getKategori()->result_array();

        $this->form_validation->set_rules('kategori', 'Kategori', 'required', [
            'required' => 'Judul event harus diisi'
        ]);

        if ($this->form_validation->run() == false) {
            $this->load->view('ad/header', $data);
            $this->load->view('ad/sidebar', $data);
            $this->load->view('ad/topbar', $data);
            $this->load->view('ad/kategori', $data);
            $this->load->view('ad/footer');
        } else {
            $data = [
                'kategori' => $this->input->post('kategori')
            ];

            $this->model_barang->simpanKategori($data);
            redirect('home_admin/kategori');
        }
    }
//...................................................................................................//
    public function hapusKategori()
    {
        $where = ['id' => $this->uri->segment(3)];
        $this->model_barang->hapusKategori($where);
        redirect('home_admin/kategori');
    }

     public function Dashboard()
    {
        $data['judul'] = 'Dashboard';
        
        $data['event'] = $this->model_barang->getevent()->result_array();

        $this->load->view('ad/header', $data);
        $this->load->view('ad/sidebar', $data);
        $this->load->view('ad/topbar', $data);
        $this->load->view('ad/dasbor', $data);
        $this->load->view('ad/footer');
    }
//...................................................................................................//
	//Awal Buku Tamu
    public function buku_tamu() {

        if($this->session->userdata("logged_in")!=="") {

            $data['data_buku_tamu'] = $this->model_barang->GetBukuTamu();

        $this->load->view('ad/header', $data);
        $this->load->view('ad/sidebar', $data);
        $this->load->view('ad/topbar', $data);
        $this->load->view('ad/buku_tamu', $data);
        $this->load->view('ad/footer');
        }
        else {
            redirect("home_admin");
        }
    }
//...................................................................................................//
    public function buku_tamu_hapus() {

        $id = $this->uri->segment(3);
        $this->model_barang->DeleteBukuTamu($id);
        
        $this->session->set_flashdata('message','Pesan Berhasil Dihapus');
        redirect("home_admin/buku_tamu");
    }
//...................................................................................................//
    public function buku_tamu_detail() {

        $id = $this->uri->segment(3);
        $status ="1";
        $query = $this->model_barang->DetailBukuTamu($id);
        foreach ($query->result_array() as $tampil) {
            $data['id_hubungikami'] = $tampil['id_hubungikami'];
            $data['nama'] = $tampil['nama'];
            $data['email'] = $tampil['email'];
            $data['hp'] = $tampil['hp'];
            $data['alamat'] = $tampil['alamat'];
            $data['pesan'] = $tampil['pesan'];
            $data['tanggal'] = $tampil['tanggal'];
        }

        $this->model_barang->UpdateStatusBukuTamu($status,$id);
        
        $this->load->view('ad/header', $data);
        $this->load->view('ad/sidebar', $data);
        $this->load->view('ad/topbar', $data);
        $this->load->view('ad/detail', $data);
        $this->load->view('ad/footer');
    }
//...................................................................................................//
    public function buku_tamu_balas() {
        if($this->session->userdata("logged_in")!=="") {

            $id = $this->uri->segment(3);
            $query = $this->model_barang->DetailBukuTamu($id);
            foreach ($query->result_array() as $tampil) {
                $data['id_hubungikami'] = $tampil['id_hubungikami'];
                $data['nama'] = $tampil['nama'];
                $data['email'] = $tampil['email'];
                $data['hp'] = $tampil['hp'];
                $data['alamat'] = $tampil['alamat'];
                $data['pesan'] = $tampil['pesan'];
                $data['tanggal'] = $tampil['tanggal'];
            }

        $this->load->view('ad/header', $data);
        $this->load->view('ad/sidebar', $data);
        $this->load->view('ad/topbar', $data);
        $this->load->view('ad/balas', $data);
        $this->load->view('ad/footer');
        }
        else {
            redirect("home_admin");
        }
    }
//...................................................................................................//
    public function buku_tamu_balas_simpan() {
        $email = $this->input->post("email");
        $judul = $this->input->post("judul");
        $isi_hubungi_kami_kirim = $this->input->post("isi_hubungi_kami_kirim");

        $this->model_barang->SimpanBukuTamuAdd($email,$judul,$isi_hubungi_kami_kirim);

        $this->load->library('email');
        $this->email->from('info@adriano.com', 'Adriano MX Online Shop');
        $this->email->to($email);   
        $this->email->subject($judul);
        $this->email->message($isi_hubungi_kami_kirim); 
        $this->email->send();
    }

//...................................................................................................//
    public function buku_tamu_add() {
        if($this->session->userdata("logged_in")!=="") {

             $id = $this->uri->segment(3);
            $query = $this->model_barang->DetailBukuTamu($id);
            foreach ($query->result_array() as $tampil) {
                $data['id_hubungikami'] = $tampil['id_hubungikami'];
                $data['nama'] = $tampil['nama'];
                $data['email'] = $tampil['email'];
                $data['hp'] = $tampil['hp'];
                $data['alamat'] = $tampil['alamat'];
                $data['pesan'] = $tampil['pesan'];
                $data['tanggal'] = $tampil['tanggal'];
            }

        $this->load->view('ad/header',$data );
        $this->load->view('ad/sidebar',$data);
        $this->load->view('ad/topbar',$data);
        $this->load->view('ad/add',$data);
        $this->load->view('ad/footer',$data);
        }
        else {
            redirect("home_admin");
        }
    }
//...................................................................................................//
    public function buku_tamu_add_simpan() {
        $email = $this->input->post("email");
        $judul = $this->input->post("judul");
        $isi_hubungi_kami_kirim = $this->input->post("isi_hubungi_kami_kirim");

        $this->model_barang->SimpanBukuTamuAdd($email,$judul,$isi_hubungi_kami_kirim);

        $this->load->library('email');
        $this->email->from('info@adriano.com', 'Adriano MX Online Shop');
        $this->email->to($email);   
        $this->email->subject($judul);
        $this->email->message($isi_hubungi_kami_kirim); 
        $this->email->send();
    }
//...................................................................................................//
    public function buku_tamu_kirim() {

        if($this->session->userdata("logged_in")!=="") {

            $data['data_buku_tamu_kirim'] = $this->model_barang->GetBukuTamuKirim();

        $this->load->view('ad/header', $data);
        $this->load->view('ad/sidebar', $data);
        $this->load->view('ad/topbar', $data);
        $this->load->view('ad/kirim', $data);
        $this->load->view('ad/footer');
        }
        else {
            redirect("home_admin");
        }
    }
//...................................................................................................//
    public function buku_tamu_kirim_hapus() {

        $id = $this->uri->segment(3);
        $this->model_barang->DeleteBukuTamuKirim($id);
        
        $this->session->set_flashdata('message','Pesan Berhasil Dihapus');
        redirect("home_admin/buku_tamu_kirim");
    }
//...................................................................................................//
    public function buku_tamu_kirim_detail() {

        $id = $this->uri->segment(3);
        $query = $this->model_barang->DetailBukuTamuKirim($id);
        foreach ($query->result_array() as $tampil) {
            $data['id_hubungi_kami_kirim'] = $tampil['id_hubungi_kami_kirim'];
            $data['kepada'] = $tampil['kepada'];
            $data['judul'] = $tampil['judul'];
            $data['isi_hubungi_kami_kirim'] = $tampil['isi_hubungi_kami_kirim'];
            
        }

        
        $this->load->view('ad/header', $data);
        $this->load->view('ad/sidebar', $data);
        $this->load->view('ad/topbar', $data);
        $this->load->view('ad/detail_kirim', $data);
        $this->load->view('ad/footer');
    }
    //Akhir Buku Tamu
//...................................................................................................//
    
    public function anggota()
    {
        $data['judul'] = 'Data Anggota';
        $data['user'] = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
        
        $data['anggota'] = $this->db->get('user')->result_array();

        $this->load->view('ad/header', $data);
        $this->load->view('ad/sidebar', $data);
        $this->load->view('ad/topbar', $data);
        $this->load->view('ad/anggota', $data);
        $this->load->view('ad/footer');
    }
//...................................................................................................//

    //Awal Tentang Kami
    public function tentangkami() {
        if ($this->session->userdata("logged_in")!=="") {

            $query = $this->Modeladmin->GetTentangkami();
            foreach ($query->result_array() as $tampil) {
                $data['id_tentangkami']=$tampil['id_tentangkami'];
                $data['judul']=$tampil['judul'];
                $data['deskripsi']=$tampil['deskripsi'];
            }

            $this->load->view('ad/header', $data);
            $this->load->view('ad/sidebar', $data);
            $this->load->view('ad/topbar', $data);
            $this->load->view('ad/tentangkami', $data);
            $this->load->view('ad/footer');
        }
        else {
            redirect("home_admin/tentangkami");
        }
    }

    public function tentangkami_simpan() {
        $id_tentangkami = $this->input->post('id_tentangkami');
        $judul = $this->input->post('judul');
        $deskripsi = $this->input->post('deskripsi');

        $this->Modeladmin->UpdateTentangkami($id_tentangkami,$judul,$deskripsi);
        redirect('home_admin/tentangkami');
    }
    //Akhir Tentang Kami
//...................................................................................................//
    //Awal Cara Pesan
    public function carapesan() {
        if ($this->session->userdata("logged_in")!=="") {

            $query = $this->Modeladmin->Getcarapesan();
            foreach ($query->result_array() as $tampil) {
                $data['id_carapesan']=$tampil['id_carapesan'];
                $data['judul']=$tampil['judul'];
                $data['deskripsi']=$tampil['deskripsi'];
                
            }

            $this->load->view('ad/header', $data);
            $this->load->view('ad/sidebar', $data);
            $this->load->view('ad/topbar', $data);
            $this->load->view('ad/carapesan', $data);
            $this->load->view('ad/footer');
        }
        else {
            redirect("home_admin/carapesan");
        }
    }

    public function carapesan_simpan() {
        $id_carapesan = $this->input->post('id_carapesan');
        $judul = $this->input->post('judul');
        $deskripsi = $this->input->post('deskripsi');


        $this->Modeladmin->Updatecarapesan($id_carapesan,$judul,$deskripsi);
         redirect('home_admin/carapesan');
    }

    //Akhir Cara Belanja
//...................................................................................................//

//manajemen event
    public function News() 
    {
        $data['judul'] = 'Berita News';
        
        $data['news'] = $this->model_barang->getnews()->result_array();
        $data['kategori'] = $this->model_barang->getkategori()->result_array();

        $this->form_validation->set_rules('judul_news', 'Judul news', 'required|min_length[3]', [
            'required' => 'Judul news harus diisi',
            'min_length' => 'Judul news terlalu pendek'
        ]);
        $this->form_validation->set_rules('id_kategori', 'Kategori', 'required', [
            'required' => 'Kategori harus dipilih',
        ]);
        $this->form_validation->set_rules('keterangan', 'Nama keterangan', 'required|min_length[3]', [
            'required' => 'Nama keterangan harus diisi',
            'min_length' => 'Nama keterangan terlalu pendek'
        ]);
        
        
        //konfigurasi sebelum gambar diupload
        $config['upload_path'] = './assets/img/upload/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = '3000';
        $config['max_width'] = '1024';
        $config['max_height'] = '1000';
        $config['file_name'] = 'img' . time();

        $this->load->library('upload', $config);

        if ($this->form_validation->run() == false) {
            $this->load->view('ad/header', $data);
            $this->load->view('ad/sidebar', $data);
            $this->load->view('ad/topbar', $data);
            $this->load->view('ad/news', $data);
            $this->load->view('ad/footer');
        } else {
            if ($this->upload->do_upload('image')) {
                $image = $this->upload->data();
                $gambar = $image['file_name'];
            } else {
                $gambar = '';
            }

            $data = [
                'judul_news' => $this->input->post('judul_news', true),
                'id_kategori' => $this->input->post('id_kategori', true),
                'keterangan' => $this->input->post('keterangan', true),
                
                'image' => $gambar
            ];

            $this->model_barang->simpannews($data);
            redirect('home_admin/news');
        }
    }
//...................................................................................................//
    public function hapusnews()
    {
        $where = ['id' => $this->uri->segment(3)];
        $this->model_barang->hapusnews($where);
        redirect('home_admin/news');
    }
//...................................................................................................//
    public function ubahnews()
    {
        $data['judul'] = 'Update Berita News';
        
        $data['news'] = $this->model_barang->newsWhere(['id' => $this->uri->segment(3)])->result_array();
        $kategori = $this->model_barang->joinkategorinews(['news.id' => $this->uri->segment(3)])->result_array();
        foreach ($kategori as $k) {
            $data['id'] = $k['id_kategori'];
            $data['k'] = $k['kategori'];
        }
        $data['kategori'] = $this->model_barang->getKategori()->result_array();

        $this->form_validation->set_rules('judul_news', 'Judul News', 'required|min_length[3]', [
            'required' => 'Judul News harus diisi',
            'min_length' => 'Judul News terlalu pendek'
        ]);
        $this->form_validation->set_rules('id_kategori', 'Kategori', 'required', [
            'required' => 'Kategori harus dipilih',
        ]);
        $this->form_validation->set_rules('keterangan', 'Nama keterangan', 'required|min_length[3]', [
            'required' => 'Nama keterangan harus diisi',
            'min_length' => 'Nama keterangan terlalu pendek'
        ]);
         
     
        //konfigurasi sebelum gambar diupload
        $config['upload_path'] = './assets/img/upload/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['max_size'] = '3000';
        $config['max_width'] = '1024';
        $config['max_height'] = '1000';
        $config['file_name'] = 'img' . time();

        //memuat atau memanggil library upload
        $this->load->library('upload', $config);

        if ($this->form_validation->run() == false) {
            $this->load->view('ad/header', $data);
            $this->load->view('ad/sidebar', $data);
            $this->load->view('ad/topbar', $data);
            $this->load->view('ad/ubah_news', $data);
            $this->load->view('ad/footer');
        } else {
            if ($this->upload->do_upload('image')) {
                $image = $this->upload->data();
                unlink('assets/img/upload/' . $this->input->post('old_pict', TRUE));
                $gambar = $image['file_name'];
            } else {
                $gambar = $this->input->post('old_pict', TRUE);
            }

            $data = [
                'judul_news' => $this->input->post('judul_news', true),
                'id_kategori' => $this->input->post('id_kategori', true),
                'keterangan' => $this->input->post('keterangan', true),
                'ckeditor' => $this->input->post('ckeditor', true),
                
                'image' => $gambar
            ];

            $this->model_barang->updatenews($data, ['id' => $this->input->post('id')]);
            redirect('home_admin/news');
        }
    }




}


