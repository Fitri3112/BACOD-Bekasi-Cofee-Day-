 <?php
class Hubungi_kami extends CI_Controller
{
 function __construct()
	 {
		 parent::__construct();
		 $this->load->model(['ModelUser','ModelSeminar','home_model']);

	 }
	public function index () 
	
	
	{

		$data = ['judul' => "Hubungi kami",];
		 //jika sudah login dan jika belum login
		 
		 if ($this->session->userdata('email')) {
		 $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
		 
		 $data['user'] = $user['nama'];
		 
		$this->load->view('home/header', $data);
		$this->load->view('home/hubungi_kami.php', $data);
		$this->load->view('home/modal');
		$this->load->view('home/footer', $data);

		} else {
		 
		 $data['user'] = 'Pengunjung';
		 
		 
		$this->load->view('home/header', $data);
		$this->load->view('home/hubungi_kami.php', $data);
		$this->load->view('home/modal');
		$this->load->view('home/footer', $data);
		}
		
	}
//...................................................................................................//
	public function hubungi_kami_kirim() {
		$tanggal 	= date('Y-m-d');
		$nama 		= $this->input->post('nama');
		$email 		= $this->input->post('email');
		$hp 		= $this->input->post('hp');
		$alamat 		= $this->input->post('alamat');
		$pesan 		= $this->input->post('pesan');

		$this->home_model->InsertHubungiKami($nama,$email,$hp,$alamat,$pesan,$tanggal);

		$this->session->set_flashdata('sukses','Data Berhasil Dikirim');
		redirect("/hubungi_kami");
	}


}