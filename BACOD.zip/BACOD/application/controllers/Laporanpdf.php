<?php
Class Laporanpdf extends CI_Controller{
    
    function __construct() {
        parent::__construct();
        $this->load->library('pdf');
    }
    
    function index(){
        $pdf = new FPDF('l','mm','A5');
        // membuat halaman baru
        $pdf->AddPage();
        // setting jenis font yang akan digunakan
        $pdf->SetFont('Arial','B',16);
        // mencetak string 
        $pdf->Cell(190,7,'BACOD - [ BEKASI COFFE DAY ]',0,1,'C');
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(190,7,'DAFTAR PARTICIPANT BACOD',0,1,'C');

        // Memberikan space kebawah agar tidak terlalu rapat
        $pdf->Cell(10,7,'',0,1);

        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(35,6,'NAMA',1,0);
        $pdf->Cell(50,6,'ALAMAT',1,0);
        $pdf->Cell(35,6,'EMAIL',1,0);
       
        $pdf->Cell(35,6,' MAMBER SEJAK ',1,1);


        $pdf->SetFont('Arial','',10);

        $user = $this->db->get('user')->result();
        foreach ($user as $row){
            $pdf->Cell(35,6,$row->nama,1,0);
            $pdf->Cell(50,6,$row->alamat,1,0);
            $pdf->Cell(35,6,$row->email,1,0);
            
            $pdf->Cell(35,6,$row->tanggal_input,1,1); 
        }

        $pdf->Output();
    }
}