<?php
class Member extends CI_Controller
{
	 function __construct()
	 {
		 parent::__construct();
		 $this->load->model(['ModelUser','ModelKomentar','ModelSeminar','home_model','model_barang']);
	 }
	 public function index()
	 {
		$this->_login();
		 $data['user'] = $user['nama'];
	 }

//...................................................................................................//
	 private function _login()
	 {
		 $email = htmlspecialchars($this->input->post('email', true));
		 $password = $this->input->post('password', true);
		 $user = $this->ModelUser->cekData(['email' => $email])->row_array();
		 //jika usernya ada
		 if ($user) 
		 {
		//jika user sudah aktif
			if ($user['is_active'] == 1) 
			{
			//cek password
					 if (password_verify($password, $user['password'])) 
					 {$data = 
						 ['email' => $user['email'],
						 'role_id' => $user['role_id'],
						 'id_user' => $user['id'],
						 'nama' => $user['nama']];
						 $this->session->set_userdata($data);
						 redirect('home');
						 } else {
						 $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-message" role="alert">Password salah!!</div>');
						 redirect('home');
						 }
						 } else {
						 $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-message" role="alert">User belum diaktifasi!!</div>');
						 redirect('home');
						}
						 } else {
						 $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-message" role="alert">Email tidak terdaftar!!</div>');
						 redirect('home');
		
	 }
 }
 
//...................................................................................................//
 public function daftar()
 {
	 $this->form_validation->set_rules('nama', 'Nama Lengkap', 'required', 
		['required' => 'Nama Belum diis!!']);
	 $this->form_validation->set_rules('alamat', 'Alamat Lengkap', 'required', 
		['required' => 'Alamat Belum diis!!']);
	 $this->form_validation->set_rules('email', 'Alamat Email', 'required|trim|valid_email|is_unique[user.email]', 
		[
		'valid_email' => 'Email Tidak Benar!!',
		 'required' => 'Email Belum diisi!!',
		 'is_unique' => 'Email Sudah Terdaftar!'
		 ]);
	 $this->form_validation->set_rules('password1', 'Password', 'required|trim|min_length[3]|matches[password2]', 
		 [
		 'matches' => 'Password Tidak Sama!!',
		 'min_length' => 'Password Terlalu Pendek'
		 ]);
	 $this->form_validation->set_rules('password2', 'Repeat Password', 'required|trim|matches[password1]');
	 $email = $this->input->post('email', true);
	 $data = 
		 [
		 'nama' => htmlspecialchars($this->input->post('nama', true)),
		 'alamat' => $this->input->post('alamat', true),
		 'email' => htmlspecialchars($email),
		 'image' => 'default.jpg',
		 'password' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
		 'role_id' => 2,
		 'is_active' => 1,
		 'tanggal_input' => $this->input->post('tanggal_input', true),
		 ];
	 $this->ModelUser->simpanData($data);
	 $this->session->set_flashdata('pesan', '<div class="alert alertsuccess alertmessage" role="alert">Selamat!! akun anggota anda sudah dibuat.</div>');
	 redirect(base_url());
 }
 
 //...................................................................................................//
 public function myProfil()
 {

	 $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
	 foreach ($user as $a) {
	 $data = [
	 'image' => $user['image'],
	 'user' => $user['nama'],
	 'email' => $user['email'],
	 'tanggal_input' => $user['tanggal_input'],
	 ];
	 }
	  $data['judul'] = 'Profil Saya';
	 $this->load->view('home/header', $data);
	 $this->load->view('home/index', $data);
	 $this->load->view('home/modal');
	 $this->load->view('home/footer', $data);
	 }

//.........................................................................................................//
public function ubahProfil()
 {
	
	 $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
	 foreach ($user as $a) {
		 $data = [
		 'image' => $user['image'],
		 'user' => $user['nama'],
		 'email' => $user['email'],
		 'tanggal_input' => $user['tanggal_input'],
		 ];
	 }
	 $this->form_validation->set_rules('nama', 'Nama Lengkap', 'required|trim', [
	 'required' => 'Nama tidak Boleh Kosong'
	 ]);
	 $data['judul'] = 'Ubah Profil Saya';
	 if ($this->form_validation->run() == false) {
		 $this->load->view('home/header', $data);
		 $this->load->view('home/ubah-anggota', $data);
		 $this->load->view('home/modal');
		 $this->load->view('home/footer', $data);
	 } else {
	 $nama = $this->input->post('nama', true);
	 $email = $this->input->post('email', true);
	 
	 //jika ada gambar yang akan diupload
	 $upload_image = $_FILES['image']['name'];
	 if ($upload_image) {
		 $config['upload_path'] = './assets/img/profile/';
		 $config['allowed_types'] = 'gif|jpg|png';
		 $config['max_size'] = '3000';
		 $config['max_width'] = '1024';
		 $config['max_height'] = '1000';
		 $config['file_name'] = 'pro' . time();
		 $this->load->library('upload', $config);
		 if ($this->upload->do_upload('image')) {
			 $gambar_lama = $data['user']['image'];
			 if ($gambar_lama != 'default.jpg') {
				unlink(FCPATH . 'assets/img/profile/' . $gambar_lama);
			 }
			 $gambar_baru = $this->upload->data('file_name');
			 $this->db->set('image', $gambar_baru);
		 } else {
		 }
	 }
	 $this->db->set('nama', $nama);
	 $this->db->where('email', $email);
	 $this->db->update('user');
	 $this->session->set_flashdata('pesan', '<div class="alert alertsuccess alert-message" role="alert">Profil Berhasil diubah </div>');
	 redirect('member/myprofil');
	 }
 }

//...................................................................................................//
public function logout()
 {
 $this->session->unset_userdata('email');
 $this->session->unset_userdata('role_id');
 $this->session->set_flashdata('pesan', '<div class="alert alertsuccess alert-message" role="alert">Anda telah logout!!</div>');
 redirect('home');
 }

//................................................................................//
 public function produk () {
		$id_produk = $this->uri->segment(3);

		
		$data['bank'] 			= $this->home_model->GetBank(); 
		
		$data['kategori'] 		= $this->home_model->GetKategori(); 
		
		$data['random']			= $this->home_model->GetRandomProduk();
		$data['random_active']	= $this->home_model->GetRandomActiveProduk();

		$data['data_produk']= $this->home_model->GetProdukId($id_produk);
	 
	 
	$this->load->view('home/header', $data);
	$this->load->view('home/h-participant', $data);
	$this->load->view('home/modal');
	$this->load->view('home/footer', $data);
	
	}

//...................................................................................................//
public function Event (){
	$data['barang']=$this->model_barang->tampil_data()->result();
	$this->load->view('home/header', $data);
	$this->load->view('home/daftar', $data);
	$this->load->view('home/modal');
	$this->load->view('home/footer', $data);
			}

//...................................................................................................//
  public function detailevent($id) 
        {

       
     if ($this->session->userdata('email')) {
	 $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
	 $data['event']=$this->model_barang->getevent()->result();
	 $event = $this->model_barang->joinKategorievent(['event.id' => $id])->result(); 
     $data['event']=$this->model_barang->detailevent($id);
	 $data['user'] = $user['nama'];
	 $data['title'] = "Detail event"; 
	
	 $this->load->view('home/header', $data);
	 $this->load->view('home/detail-event', $data);
	 $this->load->view('home/modal');
	 $this->load->view('home/footer', $data);

	} else {
	 
	 $data['user'] = 'Pengunjung';
	 
	 
	$this->load->view('home/header', $data);
	$this->load->view('home/h-pengunjung', $data);
	$this->load->view('home/modal');
	$this->load->view('home/footer', $data);
        }
    }
//...................................................................................................//
    public function tambahBooking() 
        { 
        $id_event = $this->uri->segment(3); 
        //memilih data event yang untuk dimasukkan ke tabel temp/keranjang melalui variabel $isi 
        $d = $this->db->query("Select*from event where id='$id_event'")->row(); 
        //berupa data2 yang akan disimpan ke dalam tabel temp/keranjang 
        $isi = [ 
                'id_event' => $id_event, 
                'judul_event' => $d->judul_event, 
                'id_user' => $this->session->userdata('id_user'), 
                'email_user' => $this->session->userdata('email'), 
                'tgl_booking' => date('Y-m-d H:i:s'), 
                'image' => $d->image, 
                'penulis' => $d->pengarang, 
                'penerbit' => $d->penerbit, 
                'tahun_terbit' => $d->tahun_terbit 
                ]; 
        //cek apakah event yang di klik booking sudah ada di keranjang
        $temp = $this->ModelBooking->getDataWhere('temp', ['id_event' => $id_event])->num_rows(); 
        $userid = $this->session->userdata('id_user'); 
        //cek jika sudah memasukan 3 event untuk dibooking dalam keranjang 
        $tempuser = $this->db->query("select*from temp where id_user ='$userid'")->num_rows(); 
        //cek jika masih ada booking event yang belum diambil 
        $databooking = $this->db->query("select*from booking where id_user='$userid'")->num_rows(); 
        if ($databooking > 0) 
            { 
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-message" role="alert">Masih Ada booking event sebelumnya yang belum diambil.<br> Ambil event yang dibooking atau tunggu 1x24 Jam untuk bisa booking kembali </div>'); 
redirect(base_url()); 
            } 
        //jika event yang diklik booking sudah ada di keranjang 
        if ($temp > 0) 
            { 
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-message" role="alert">event ini Sudah anda booking </div>'); 
            redirect(base_url() . 'home'); 
            } 
        //jika event yang akan dibooking sudah mencapai 3 item 
        if ($tempuser == 3) 
            { 
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-message" role="alert">Booking event Tidak Boleh Lebih dari 3</div>'); 
            redirect(base_url() . 'home'); 
            } 
        //membuat tabel temp jika belum ada 
        $this->ModelBooking->createTemp(); 
        $this->ModelBooking->insertData('temp', $isi); 
        //pesan ketika berhasil memasukkan event ke keranjang 
        $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-message" role="alert">event berhasil ditambahkan ke keranjang </div>'); 
        redirect(base_url() . 'home'); 
        }
//......................................................................//

}