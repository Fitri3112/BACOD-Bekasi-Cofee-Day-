<?php
class Seminar extends CI_Controller
{
	 function __construct()
	 {
		 parent::__construct();
		 $this->load->model(['ModelUser','ModelKomentar','ModelSeminar','home_model']);
		 $this->load->library('upload');
	 }
 function index()
	{
 if ($this->session->userdata('email')) {
	 $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
	 
	 $data['user'] = $user['nama'];
	 
	$this->load->view('home/header', $data);
	$this->load->view('home/seminar85', $data);
	$this->load->view('home/modal');
	$this->load->view('home/footer', $data);

	} else {
	 
	 $data['user'] = 'Pengunjung';
	 
	 
	$this->load->view('home/header', $data);
	$this->load->view('home/seminar85', $data);
	$this->load->view('home/modal');
	$this->load->view('home/footer', $data);
	
	}
		
	}
	
	function simpan_post(){
		$config['upload_path'] = './assets/img/'; //path folder
	    $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
	    $config['encrypt_name'] = TRUE; //nama yang terupload nantinya

	    $this->upload->initialize($config);
	    if(!empty($_FILES['foto']['name'])){
	        if ($this->upload->do_upload('foto')){
	        	$gbr = $this->upload->data();
	            //Compress Image
	            $config['image_library']='gd2';
	            $config['source_image']='./assets/images/'.$gbr['file_name'];
	            $config['create_thumb']= FALSE;
	            $config['maintain_ratio']= FALSE;
	            $config['quality']= '80%';
	            $config['width']= 710;
	            $config['height']= 420;
	            $config['new_image']= './assets/images/'.$gbr['file_name'];
	            $this->load->library('image_lib', $config);
	            $this->image_lib->resize();

	            $nama=$this->input->post('nama');
				$email = $this->input->post('email');
				$tgl=$this->input->post('tgl');
				$jk=$this->input->post('jk');
				$pd=$this->input->post('pd');
				$alamat=$this->input->post('alamat');
				$ttl=$this->input->post('tanggal_lahir');
				$foto=$foto['file_name'];
				
				

				$this->ModelSeminar->simpan_seminar($nama,$email,$tgl,$pd,$alamat,$foto);
				redirect('seminar/lists');
				$this->ModelSeminar->simpan_seminar($nama,$email,$tgl,$pd,$alamat,$foto);
				redirect('seminar/view');
		}else{
			redirect('seminar');
	    }
	                 
	    }else{
			redirect('seminar');
		}
				
	}
function lists(){
		$x['data']=$this->ModelSeminar->get_all_seminar();
		
		$this->load->view('home/header', $x);
		 $this->load->view('home/seminar85list', $x);
		 $this->load->view('home/modal');
		 $this->load->view('home/footer', $x);
	}
	function view(){
		$kode=$this->uri->segment(3);
		$x['data']=$this->ModelSeminar->get_seminar_by_kode($kode);
		
		$this->load->view('home/header', $x);
		 $this->load->view('home/seminar85view', $x);
		 $this->load->view('home/modal');
		 $this->load->view('home/footer', $x);
	}
	

}

	
	





