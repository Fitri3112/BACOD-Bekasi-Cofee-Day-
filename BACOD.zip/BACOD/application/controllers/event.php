<?php 
class Event extends CI_Controller 
    { 
    function __construct() 
        { 
        parent::__construct(); 
        $this->load->model(['ModelUser','ModelKomentar','ModelSeminar','home_model','model_barang']);
        } 
    public function index() 
        { 
        $data = [
            'judul' => "Katalog event", 'event' => $this->model_barang->getevent()->result(),
        ];
        //jika sudah login dan jika belum login 
        if ($this->session->userdata('email')) 
            { 
            $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array(); 

            $data['user'] = $user['nama'];

             $this->load->view('home/header', $data);
             $this->load->view('home/h-participant', $data);
             $this->load->view('home/modal');
             $this->load->view('home/footer', $data);

            } else {
             
             $data['user'] = 'Pengunjung';
             
             
            $this->load->view('home/header', $data);
            $this->load->view('home/h-pengunjung', $data);
            $this->load->view('home/modal');
            $this->load->view('home/footer', $data);
            }
        }
    public function detailevent() 
        { 
        $id = $this->uri->segment(3); 
        $event = $this->model_barang->joinKategorievent(['event.id' => $id])->result(); 
        $data['user'] = "Pengunjung"; 
        $data['title'] = "Detail event"; 
        
        foreach ($event as $fields) 
            { 
            $data['judul'] = $fields->judul_event; 
            $data['keterangan'] = $fields->keterangan; 
            
            $data['kategori'] = $fields->kategori; 
            
            $data['harga'] = $fields->harga; 
            $data['image'] = $fields->image; 
            $data['dipesan'] = $fields->dipesan; 
            $data['dibeli'] = $fields->dibeli; 
            $data['stok'] = $fields->stok; 
            $data['id'] = $id; 
            } 
        $this->load->view('home/header', $data);
        $this->load->view('home/detail-event', $data); 
        $this->load->view('home/modal'); 
        $this->load->view('home/footer'); 
        }

   
    }
?>
