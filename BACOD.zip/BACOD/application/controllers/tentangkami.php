<?php
class Tentangkami extends CI_Controller
{
	 function __construct()
	 {
		 parent::__construct();
		 $this->load->model(['ModelUser','ModelKomentar','ModelSeminar','home_model']);
	 }
	 public function index()
	{
	 $data = [
		 'judul' => "SEPONSOR",
		 
			];
	 //jika sudah login dan jika belum login
	 
	 if ($this->session->userdata('email')) {
	 $user = $this->ModelUser->cekData(['email' => $this->session->userdata('email')])->row_array();
	 
	 $data['user'] = $user['nama'];
	 
	$this->load->view('home/header', $data);
	$this->load->view('home/about.php', $data);
	$this->load->view('home/modal');
	$this->load->view('home/footer', $data);

	} else {
	 
	 $data['user'] = 'Pengunjung';
	 
	 
	$this->load->view('home/header', $data);
	$this->load->view('home/about.php', $data);
	$this->load->view('home/modal');
	$this->load->view('home/footer', $data);
	}}

//......................................................................//

 
}
		
		