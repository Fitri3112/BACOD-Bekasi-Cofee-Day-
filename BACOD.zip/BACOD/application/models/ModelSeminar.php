<?php
class ModelSeminar extends CI_Model{

	function simpan_seminar($nama,$email,$tgl,$pd,$alamat,$foto){
		$hsl=$this->db->query("INSERT INTO seminar (nama,email,pendidikan,alamat,jk,tanggal_lahir,foto) 
		VALUES ('$nama','$email','$tgl','$pd','$alamat','$foto','$tgli')");
		return $hsl;
	}

	function get_seminar_by_kode($kode){
		$hsl=$this->db->query("SELECT * FROM seminar WHERE id='$kode'");
		return $hsl;
	}

	function get_all_seminar(){
		$hsl=$this->db->query("SELECT * FROM seminar ORDER BY id DESC");
		return $hsl;
	}
	function GetBank() {
		return $this->db->query("select * from tbl_bank order by id_bank desc");
	}
}