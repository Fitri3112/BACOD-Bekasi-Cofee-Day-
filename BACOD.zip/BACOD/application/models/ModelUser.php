<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ModelUser extends CI_Model
{
    public function simpanData($data = null)
    {
        $this->db->insert('user', $data);
    }

    public function cekData($where = null)
    {
        return $this->db->get_where('user', $where);
    }

    public function getUserWhere($where = null)
    {
        return $this->db->get_where('user', $where);
    }

    public function cekUserAccess($where = null)
    {
        $this->db->select('*');
        $this->db->from('access_menu');
        $this->db->where($where);
        return $this->db->get();
    }

    public function getUserLimit()
    {
        $this->db->select('*');
        $this->db->from('user');
        $this->db->limit(10, 0);
        return $this->db->get();
    }
    function GetKategori() {
        return $this->db->query("select * from tbl_kategori order by id_kategori desc");
    }

    function GetProduk($id_produk,$kode_produk,$nama_produk,$harga,$stok,$deskripsi,$gambar,$kategori_id) {
        return $this->db->query("select a.*,b.*,c.* from tbl_produk a join tbl_brand b on a.brand_id=b.id_brand join tbl_kategori c on a.kategori_id=c.id_kategori order by id_produk desc limit 0,6 ");
    }

    function GetRandomProduk() {
        return $this->db->query("select a.*,b.*,c.* from tbl_produk a join tbl_brand b on a.brand_id=b.id_brand join tbl_kategori c on a.kategori_id=c.id_kategori order by RAND('id_produk') asc limit 0,3 ");
    }

    function GetRandomActiveProduk() {
        return $this->db->query("select a.*,b.*,c.* from tbl_produk a join tbl_brand b on a.brand_id=b.id_brand join tbl_kategori c on a.kategori_id=c.id_kategori order by RAND('id_produk') desc limit 0,3 ");
    }

function CekAdminLogin($username,$password) {

        

        $ceklogin = $this->db->query("select * from tbl_admin where username='$username' and password='$password'");

        if (count($ceklogin->result())>0) {

            foreach ($ceklogin->result() as $value) {
                $sess_data['logged_in']     = 'LoginOke';
                $sess_data['id_admin']      = $value->id_admin;
                $sess_data['nama_admin']    = $value->nama_admin;
                $sess_data['username']      = $value->username;
                $sess_data['password']      = $value->password;
                $sess_data['email']         = $value->email;
                $sess_data['phone']         = $value->phone;
                $sess_data['hak_akses']     = $value->hak_akses;

                $this->session->set_userdata($sess_data);

            }
            redirect("home_admin/Dashboard");
        }
        else {
            $this->session->set_flashdata("error","Username atau Password Anda Salah!");
            redirect('home_admin/index');
        }

    }

}
