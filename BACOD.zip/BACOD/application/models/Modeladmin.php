<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Modeladmin extends CI_Model
{
    public function simpanData($data = null)
    {
        $this->db->insert('tbl_admin', $data);
    }

    public function cekData($where = null)
    {
        return $this->db->get_where('tbl_admin', $where);
    }

    public function getadminWhere($where = null)
    {
        return $this->db->get_where('tbl_admin', $where);
    }

    public function cekadminAccess($where = null)
    {
        $this->db->select('*');
        $this->db->from('access_menu');
        $this->db->where($where);
        return $this->db->get();
    }

    public function getadminLimit()
    {
        $this->db->select('*');
        $this->db->from('admin');
        $this->db->limit(10, 0);
        return $this->db->get();
    }
   
   //Awal Tentang Kami
    function GetTentangkami() {
        return $this->db->query("select * from tbl_tentangkami");
    }

    function UpdateTentangkami($id_tentangkami,$judul,$deskripsi){
        return $this->db->query("update tbl_tentangkami set judul='$judul',deskripsi='$deskripsi' where id_tentangkami='$id_tentangkami'");
    }
    //Akhir Tentang Kami

//Awal Cara Belanja
    function Getcarapesan() {
        return $this->db->query("select * from tbl_carapesan");
    }

    function Updatecarapesan($id_carapesan,$judul,$deskripsi){
        return $this->db->query("update tbl_carapesan set judul='$judul',deskripsi='$deskripsi'where id_carapesan='$id_carapesan'");
    }

}
