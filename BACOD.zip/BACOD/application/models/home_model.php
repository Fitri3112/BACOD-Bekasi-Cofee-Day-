<?php

class home_model extends CI_Model {


	

	function InsertHubungiKami($nama,$email,$hp,$alamat,$pesan,$tanggal) {
		return $this->db->query("insert into tbl_hubungikami values('','$nama','$email','$hp','$alamat','$pesan','$tanggal','')");
	}


	function Getcarapesan() {
		return $this->db->query("select * from tbl_carapesan");
	}

	function Gettentangkami() {
		return $this->db->query("select * from tbl_tentangkami");
	}

	function GeteventId($id) {
		return $this->db->query("select a.*,b.*,c.* from event a join kategori b on a.id=b.id_kategori  where a.id='$id'");
	}

	function GetBank() {
		return $this->db->query("select * from tbl_bank order by id_bank desc");
	}
	function cek_kode($tgl)
	{
		$query=$this->db->query("select MAX(kode_transaksi) as kd from tbl_transaksi_header where kode_transaksi like '%$tgl%'");
		return $query;
	}

	function update_dibeli($kd,$bl)
	{
		$query=$this->db->query("update tbl_produk set stok='$bl' where kode_produk='$kd'");
	}

	function simpan_pesanan($datainput)
	{
		$q = $this->db->query($datainput);
	}

	function InsertTransaksiHeader($kode_trans,$penerima,$email,$alamat,$no_telepon,$propinsi,$kota,$kode_pos,$bank_id,$jasapengiriman_id) {
		return $this->db->query("insert into tbl_transaksi_header values('','$kode_trans','$penerima','$email','$alamat','$no_telepon','$propinsi','$kota','$kode_pos','$bank_id','$jasapengiriman_id','')");
	}
}