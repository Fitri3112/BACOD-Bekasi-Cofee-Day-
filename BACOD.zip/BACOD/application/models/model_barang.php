<?php

 class Model_barang extends CI_Model
{


    //manajemen event
    public function getevent()
    {
        return $this->db->get('event');
    }
//...................................................................................................//
    public function eventWhere($where)
    {
        return $this->db->get_where('event', $where);
    }
//...................................................................................................//
    public function simpanevent($data = null)
    {
        $this->db->insert('event',$data);
    }
//...................................................................................................//
    public function updateevent($data = null, $where = null)
    {
        $this->db->update('event', $data, $where);
    }
//...................................................................................................//
    public function hapusevent($where = null)
    {
        $this->db->delete('event', $where);
    }
//...................................................................................................//
    public function total($field, $where)
    {
        $this->db->select_sum($field);
        if(!empty($where) && count($where) > 0){
            $this->db->where($where);
        }
        $this->db->from('event');
        return $this->db->get()->row($field);
    }
//...................................................................................................//
    public function detailevent($id)
    {
        $result=$this->db->where('id',$id)->get('event');
        if ($result->num_rows()>0){
                return $result->result();
            }else{
                return false;
            }
        
    }

//...................................................................................................//    
  //manajemen kategori
    public function getKategori()
    {
        return $this->db->get('kategori');
    }
//...................................................................................................//
    public function kategoriWhere($where)
    {
        return $this->db->get_where('kategori', $where);
    }
//...................................................................................................//
    public function simpanKategori($data = null)
    {
        $this->db->insert('kategori', $data);
    }
//...................................................................................................//
    public function hapusKategori($where = null)
    {
        $this->db->delete('kategori', $where);
    }
//...................................................................................................//
    public function updateKategori($where = null, $data = null)
    {
        $this->db->update('kategori', $data, $where);
    }
//...................................................................................................//
    //join
    public function joinKategorievent($where)
    {
        $this->db->select('event.id_kategori,kategori.kategori');
        $this->db->from('event');
        $this->db->join('kategori','kategori.id = event.id_kategori');
        $this->db->where($where);
        return $this->db->get();
    }
//...................................................................................................//    
    function GetTentangkami() {
		return $this->db->query("select * from tbl_tentangkami");
	}
//...................................................................................................//
	function UpdateTentangkami($id_tentangkami,$judul,$deskripsi){
		return $this->db->query("update tbl_tentangkami set judul='$judul',deskripsi='$deskripsi' where id_tentangkami='$id_tentangkami'");
	}

    //Awal Buku Tamu

    function GetBukuTamu () {
        return $this->db->query("select * from tbl_hubungikami order by status asc");
    }

    function DeleteBukuTamu($id) {
        return $this->db->query("delete from tbl_hubungikami where id_hubungikami='$id'");
    }

    function DetailBukuTamu($id) {
        return $this->db->query("select * from tbl_hubungikami where id_hubungikami='$id'");
    }

    function UpdateStatusBukuTamu($status,$id) {
        return $this->db->query("update tbl_hubungikami set status='$status' where id_hubungikami='$id'");
    }

    function SimpanBukuTamuAdd($email,$judul,$isi_hubungi_kami_kirim) {
        return $this->db->query("insert into tbl_hubungi_kami_kirim values('','$email','$judul','$isi_hubungi_kami_kirim')");   
    }

    function GetBukuTamuKirim() {
        return $this->db->query("select * from tbl_hubungi_kami_kirim order by id_hubungi_kami_kirim desc");
    }

    function DeleteBukuTamuKirim($id) {
        return $this->db->query("delete from tbl_hubungi_kami_kirim where id_hubungi_kami_kirim='$id'");
    }

    function DetailBukuTamuKirim($id) {
        return $this->db->query("select * from tbl_hubungi_kami_kirim where id_hubungi_kami_kirim='$id'");
    }
    
    //Akhir Buku Tamu

 //manajemen news
    public function getnews()
    {
        return $this->db->get('news');
    }
//...................................................................................................//
    public function newsWhere($where)
    {
        return $this->db->get_where('news', $where);
    }
//...................................................................................................//
    public function simpannews($data = null)
    {
        $this->db->insert('news',$data);
    }
//...................................................................................................//
    public function updatenews($data = null, $where = null)
    {
        $this->db->update('news', $data, $where);
    }
//...................................................................................................//
    public function hapusnews($where = null)
    {
        $this->db->delete('news', $where);
    }

//...................................................................................................//
    public function detailnews($id)
    {
        $result=$this->db->where('id',$id)->get('news');
        if ($result->num_rows()>0){
                return $result->result();
            }else{
                return false;
            }
        
    }

 //...................................................................................................//    

//...................................................................................................//
    //join
    public function joinKategoriNews($where)
    {
        $this->db->select('news.id_kategori,kategori.kategori');
        $this->db->from('news');
        $this->db->join('kategori','kategori.id = news.id_kategori');
        $this->db->where($where);
        return $this->db->get();
    }

 } 