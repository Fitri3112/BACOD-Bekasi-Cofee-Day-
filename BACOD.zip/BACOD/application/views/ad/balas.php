 <?php
    $query = $this->db->query("select count(status) as stts from tbl_hubungikami where status='0'");
        foreach ($query->result_array() as $tampil) {
        	$status = $tampil['stts'];
        }
?>
<table class="table table-striped table-advance table-hover" >

        <div class="row no-gutters">

			
							<tr>
							<td class="bi bi-pencil-square" colspan="">
								<a href="<?php echo base_url();?>home_admin/buku_tamu_add" data-title="Compose" class="	fas fa-user-edit fa-2x"> 
								Compose
								</a>
							</td>
						
							<td class="inbox active" colspan="">
								<?php
							if ($status!="0") { ?>
							<a href="<?php echo base_url();?>home_admin/buku_tamu" class="fa fa-inbox fa-2x" data-title="Inbox">Inbox(<?php echo $status;?>)</a>
							<?php
							}
							else { ?>
								<a href="<?php echo base_url();?>home_admin/buku_tamu" class="fa fa-inbox fa-2x" data-title="Inbox">Inbox</a>
							<?php
							}
							?><b></b>
							</td>
						
							<td class="sent" colspan=""><a class="fas fa-paper-plane fa-2x" href="<?php echo base_url();?>home_admin/buku_tamu_kirim"  data-title="Sent">Sent</a><b></b></li>
							</td>
						


						</tr>
						
					</div>
				</div>

				<tr>
					<td colspan="3">
					<div class="span10">
						<div class="inbox-header">
							<h1 class="pull-left">Reply Message</h1>
							
						</div>
						<div class="inbox-loading"></div>
						<div class="inbox-content">

							<div class="inbox-compose form-horizontal" >
	
									<div class="inbox-control-group">
										<label class="control-label">To:</label>
										<div class="controls">
											<input type="text" class="form-control" name="email" id="email" value="<?php echo $email;?>">
											
										</div>
									</div>
									<div class="inbox-control-group">
										<label class="control-label">Subject:</label>
										<div class="controls">
											<input type="text" class="form-control" name="judul" id="judul">
										</div>
									</div>
									<div class="inbox-control-group">
										<textarea class="form-control" id="ckeditor" name="isi_hubungi_kami_kirim" id="isi_hubungi_kami_kirim" rows="12"></textarea>
									</div>
									
									
									<div class="inbox-compose-btn">
										<button class="badge badge-info" id="simpan"><i class="fas fa-paper-plane fa-2x">Send</i></button>
										
										
									</div>
							</div>
							
						</div>
					</div>
</div>
</td>
</tr>
</table>

<script type="text/javascript">
	
	$(document).ready(function(){
		
		$("#simpan").click(function(){

			var email = $("#email").val();
			var judul = $("#judul").val();
			var isi_hubungi_kami_kirim = $("#isi_hubungi_kami_kirim").val();

			var email_check = email.split("@");

			

			if (email=="") {
				alert("To Masih Kosong");
				$("#email").focus();
			}
			else if (judul=="") {
				alert("Subject Masih Kosong");
				$("#judul").focus();
			}
			else if (isi_hubungi_kami_kirim=="") {
				alert("Isi Pesan Masih Kosong");
				$("#isi_hubungi_kami_kirim").focus();
			}

			else if (email!=""){
                            if (email_check[1]) {
                                var email_check2 = email_check[1].split(".");
                            }
                                                
                            if (!email_check[1] || !email_check2[0] || !email_check2[1]) {
                                alert('Penulisan Email Tidak Valid');
                                return false;
                            }
                            else {
                            	 $.ajax({
                                    type:"POST",
                                    url :"<?php echo base_url();?>home_admin/buku_tamu_balas_simpan",
                                     data:"email="+email+"&judul="+judul+"&isi_hubungi_kami_kirim="+isi_hubungi_kami_kirim,
                                    success : function (data) {
                                   	alert("Pesan Berhasil Dikirim")
   									window.location.href="<?php echo base_url();?>home_admin/buku_tamu_kirim";
                                    }


                                    });

                            }
                    }

		});


		
	})
</script>
						
				


