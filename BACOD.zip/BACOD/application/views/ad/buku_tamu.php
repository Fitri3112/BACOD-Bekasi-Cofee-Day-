 <?php
    $query = $this->db->query("select count(status) as stts from tbl_hubungikami where status='0'");
        foreach ($query->result_array() as $tampil) {
        	$status = $tampil['stts'];
        }
?>
<table class="table table-striped table-advance table-hover" >

        <div class="row no-gutters">

					 <div class="col-md-4">
						<div class="inbox-nav margin-bottom-10">
							<tr >
								<td colspan="2"></td>
							<td class="bi bi-pencil-square" colspan="">
								<a href="<?php echo base_url();?>home_admin/buku_tamu_add" data-title="Compose" class="	fas fa-user-edit fa-2x"> 
								Compose
								</a>
							</td>
						
							<td class="inbox active" colspan="">
								<?php
							if ($status!="0") { ?>
							<a href="<?php echo base_url();?>home_admin/buku_tamu" class="fa fa-inbox fa-2x" data-title="Inbox">Inbox(<?php echo $status;?>)</a>
							<?php
							}
							else { ?>
								<a href="<?php echo base_url();?>home_admin/buku_tamu" class="fa fa-inbox fa-2x" data-title="Inbox">Inbox</a>
							<?php
							}
							?><b></b>
							</td>
						
							<td class="sent" colspan=""><a class="fas fa-paper-plane fa-2x" href="<?php echo base_url();?>home_admin/buku_tamu_kirim"  data-title="Sent">Sent</a><b></b></li>
							</td>
						


						</tr>
						
					</div>
				</div>

				<tr><td></td></tr>
				
						
						
							<?php 
									$pesan = $this->session->flashdata('message');
													if ($this->session->flashdata('message')){
									echo "<div class='alert alert-error show'>
												                   <span>Pesan Berhasil Dihapus</span>  
												                </div>";
													}
												
							?>
						
	
	<tbody>
		<center><li class="fa fa-inbox fa-2x" colspan="5">Inbox</li></center>
		<?php
		foreach ($data_buku_tamu->result_array() as $tampil) { ?>

		<?php
		if ($tampil['status']=="1") {?>
		
		<tr >
			<td class="inbox-small-cells">
				
			</td>
			<td class="inbox-small-cells"> <a href="<?php echo base_url();?>home_admin/buku_tamu_hapus/<?php echo $tampil['id_hubungikami'];?>">  <i class="icon-trash"></i></a></td>
			<td class="view-message  hidden-phone"><a href="<?php echo base_url();?>home_admin/buku_tamu_detail/<?php echo $tampil['id_hubungikami'];?>"><?php echo $tampil['nama'];?></a></td>
			<td class="view-message "><a href="<?php echo base_url();?>home_admin/buku_tamu_detail/<?php echo $tampil['id_hubungikami'];?>"><?php echo substr($tampil['pesan'],0,50);?></a></td>
			<td class="view-message "><a href="<?php echo base_url();?>home_admin/buku_tamu_detail/<?php echo $tampil['id_hubungikami'];?>"><?php echo $tampil['tanggal'];?></a></td>
		</tr>
		<?php
		}	
		else { ?>
		<tr class="unread">
			<td class="inbox-small-cells">
				
			</td>
			<td class="inbox-small-cells"> <a href="<?php echo base_url();?>home_admin/buku_tamu_hapus/<?php echo $tampil['id_hubungikami'];?>">  <i class="icon-trash"></i></a></td>
			<td class="view-message  hidden-phone"><b><a href="<?php echo base_url();?>home_admin/buku_tamu_detail/<?php echo $tampil['id_hubungikami'];?>"><?php echo $tampil['nama'];?></a></b></td>
			<td class="view-message "><b><a href="<?php echo base_url();?>home_admin/buku_tamu_detail/<?php echo $tampil['id_hubungikami'];?>"><?php echo substr($tampil['pesan'],0,50);?></a></b></td>
			<td class="view-message"><b><a href="<?php echo base_url();?>home_admin/buku_tamu_detail/<?php echo $tampil['id_hubungikami'];?>"><?php echo $tampil['tanggal'];?></a></b></td>
		</tr>
		<?php
		}
		?>
		
		<?php
		}
		?>
	</tbody>
</table>

						</div>
					
				</div>
</div>
