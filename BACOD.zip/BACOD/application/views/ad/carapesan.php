     <script src="<?php echo base_url();?>assets/js/jquery-1.8.3.js"></script>  
      <!-- BEGIN PAGE CONTAINER-->
      <div class="container-fluid">
        <!-- BEGIN PAGE HEADER-->
        <div class="row-fluid">
         <div class="span12">
          <h3 class="page-title">
              Setting Tentang Kami BACOD
            </h3>
            <ul class="breadcrumb">
            </ul>
						<!-- BEGIN VALIDATION STATES-->
						<div class="portlet box blue">
							<div class="portlet-title">
								
								<div class="tools">
									<a href="javascript:;" class="collapse"></a>
									
								</div>
							</div>
							<form action="<?php echo base_url().'home_admin/carapesan_simpan/'?>" method="post" enctype="multipart/form-data">
								<!-- BEGIN FORM-->
								
								<div id="form_sample_2" class="form-horizontal">
								
									<input type="hidden" name="id_carapesan" id="id_carapesan" value="<?php echo $id_carapesan;?>">
									<div class="control-group">
										<label class="control-label">Judul</label>
										<div class="controls">
											<input type="text" name="judul" id="judul" class="form-control" value="<?php echo $judul;?>"/>
										</div>
									</div>
									<div class="control-group">
										<label class="control-label">deskripsi</label>
										<div class="controls">

											<textarea id="ckeditor" class="form-control" rows="6" name="deskripsi" id="deskripsi" value="<?php echo $deskripsi;?>" ><?php echo $deskripsi;?></textarea>
											
										</div>
									</div>

									
									<div class="form-actions">
										<button type="submit" id="update" onclick="return confirm('Data Cara Pesan Berhasil di Update');" class="badge badge-info"><i class="fas fa-edit" ></i> Update</button>
										
									</div>
								</div>
								<!-- END FORM-->
							</form>
						</div>
						<!-- END VALIDATION STATES-->
					</div>
				</div>


<script type="text/javascript">
	
	$(document).ready(function(){

		$("#update").click(function(){

			var id_carapesan = $("#id_carapesan").val();
			var judul = $("#judul").val();
			var deskripsi = $("#deskripsi").val();

	            	$.ajax({
					type:"POST",
					url:"<?php echo base_url();?>home_admin/carapesan_simpan",
					data:"id_carapesan="+id_carapesan+"&judul="+judul+"&deskripsi="+deskripsi,
					success:function(data) {
						$("#box").show();
						

					}
				});
            

			
		});

	});
</script> 
          
          
          
        </div>
      </div>
      <!-- END PAGE CONTAINER-->  