 <?php
    $query = $this->db->query("select count(status) as stts from tbl_hubungikami where status='0'");
        foreach ($query->result_array() as $tampil) {
        	$status = $tampil['stts'];
        }
?>
<table class="table table-striped table-advance table-hover" >

        <div class="row no-gutters">

			
							<tr>
							<td class="bi bi-pencil-square" colspan="">
								<a href="<?php echo base_url();?>home_admin/buku_tamu_add" data-title="Compose" class="	fas fa-user-edit fa-2x"> 
								Compose
								</a>
							</td>
						
							<td class="inbox active" colspan="">
								<?php
							if ($status!="0") { ?>
							<a href="<?php echo base_url();?>home_admin/buku_tamu" class="fa fa-inbox fa-2x" data-title="Inbox">Inbox(<?php echo $status;?>)</a>
							<?php
							}
							else { ?>
								<a href="<?php echo base_url();?>home_admin/buku_tamu" class="fa fa-inbox fa-2x" data-title="Inbox">Inbox</a>
							<?php
							}
							?><b></b>
							</td>
						
							<td class="sent" colspan=""><a class="fas fa-paper-plane fa-2x" href="<?php echo base_url();?>home_admin/buku_tamu_kirim"  data-title="Sent">Sent</a><b></b></li>
							</td>
						


						</tr>
						
					</div>
				</div>
				<tr>
					<td colspan="3">
					<div class="span10">
						<div class="inbox-header">
							<h1 class="pull-left">View Message</h1>
							
						</div>
						<div class="inbox-loading"></div>
						<div class="inbox-content">
							<div class="inbox-header inbox-view-header">
	<h1 class="pull-left">Nama : <?php echo $nama;?></h1>
	
</div>
<div class="inbox-view-info row-fluid">
	<div class="span7"> 
		<span class="bold"><?php echo $alamat;?></span>
		<span>&#60;<?php echo $email;?>&#62;</span> to <span class="bold">me</span> on <?php echo $tanggal;?>
	</div>
	<div class="span5 inbox-info-btn">
		<div class="btn-group">
			<a href="<?php echo base_url();?>home_admin/buku_tamu_balas/<?php echo $id_hubungikami;?>"> <button class="btn blue reply-btn">
			<i class="fas fa-paper-plane fa-1x"> Reply</i>
			</button></a>
			
		</div>
	</div>
</div>
	</div>
<textarea class="span12  wysihtml5 m-wrap" name="pesan" id="ckeditor" id="pesan" rows="8" disabled=""><?php echo $pesan;?></textarea></div>
<hr>
				</div>
			</td>
		</tr>
	</table>
						
				


