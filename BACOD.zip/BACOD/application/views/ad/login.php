<div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

        <div class="col-lg-7">

            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row">
                        <div class="col-lg">
                            <div class="p-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4">Halaman Login!!</h1>
                                </div>
<body class="login">

    

   

    <?php if(validation_errors()) { ?>
                <div class="alert alert-error">
                   <span>Username atau Password Kosong.</span>  
                </div>
                <?php } ?>


    <?php if($this->session->flashdata('error')) { ?>
                <div class="alert alert-error">
                   <span>Username atau Password Salah!</span>  
                </div>
                <?php } ?>


        <?php echo form_open('adminweb/login','class="form-vertical"'); ?>
           
            <div id="box_message" class="hide"></div>
            
                 <div class="form-group">
                <label class="control-label visible-ie8 visible-ie9">Username</label>
                <div class="controls">
                    <div class="input-icon left">
                        <i class="icon-user"></i>
                        <input class="form-control" type="text" autocomplete="off" placeholder="Username" name="username" id="username"/>
                    </div>
                </div>
            </div>
          
            <div class="form-group">
                <label class="control-label visible-ie8 visible-ie9">Password</label>
                <div class="controls">
                    <div class="input-icon left">
                        <i class="icon-lock"></i>
                        <input class="form-control" type="password" autocomplete="off" placeholder="Password" name="password" id="password"/>
                    </div>
                </div>
            </div>
         
               
                 <button type="submit" class="btn btn-primary btn-user btn-block">
                                        Masuk
                                    </button>           
           <a class="btn btn-primary btn-user btn-block" href="<?= base_url('/'); ?>"><li   class="fas fa-coffee">_Website BACOD</li></a>
         
        <?php echo form_close(); ?>
       
    </div>
    <!-- END LOGIN -->
    <!-- BEGIN COPYRIGHT -->
    <div class="copyright">
        <center>2020 &copy; KUPSKI</center>
   
</div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

</div>