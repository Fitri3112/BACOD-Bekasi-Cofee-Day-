        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-mug-hot"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Admin BACOD </div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider">

           

            <!-- Looping Menu-->
                <div class="sidebar-heading">
                    Home
                </div>
                    <li class="nav-item active">
                        <!-- Nav Item - Dashboard -->
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo base_url('home_admin/dashboard') ?>">
                            <i class="fas fa-fw fa-tachometer-alt"></i>
                                <span>Dashboard</span></a>
                        </li>
                    </li>

                <!-- Divider -->
                <hr class="sidebar-divider mt-3">

                <!-- Heading -->
                <div class="sidebar-heading">
                    Master Data
                </div>
                    <!-- Nav Item - Dashboard -->
                    <li class="nav-item active">
                        <!-- Nav Item - Dashboard -->
                         <li class="nav-item">
                            <a class="nav-link" href="<?php echo base_url('home_admin/event') ?>">
                            <i class="fas fa-fw fa-database"></i>
                            <span>Data Event</span></a>
                      </li>
                       <hr class="sidebar-divider">
                        
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo base_url('home_admin/Transaksi') ?>">
                            <i class="fas fa-fw fa-file-invoice"></i>
                            <span>Transaksi</span></a>
                        </li>
                        <hr class="sidebar-divider">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo base_url('home_admin/kategori') ?>">
                            <i class="fas fa-fw fa-file-invoice"></i>
                            <span>Kategori</span></a>
                        </li>
                        <hr class="sidebar-divider">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo base_url('home_admin/tentangkami') ?>">
                            <i class="fas fa-fw fa-file-invoice"></i>
                            <span>Tentang Kami </span></a>
                        </li>
                        <hr class="sidebar-divider">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo base_url('home_admin/carapesan') ?>">
                            <i class="fas fa-fw fa-file-invoice"></i>
                            <span>Cara Pesan </span></a>
                        </li>
                        <hr class="sidebar-divider">
                        <li class="nav-item active">
                        <!-- Nav Item - Dashboard -->
                         <li class="nav-item">
                            <a class="nav-link" href="<?php echo base_url('home_admin/news') ?>">
                            <i class="fas fa-fw fa-database"></i>
                            <span>Berita News</span></a>
                      </li>
                     
                <!-- Divider -->
                <hr class="sidebar-divider mt-3">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar --   > 
        
        