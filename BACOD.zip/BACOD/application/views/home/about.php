<div class="card text-center">
        <h1>Tentang Kami KUPSKI</h1>
</div>

<div class="container-fluid">
   
    <div class="card text-center">
        <img src="assets/img/KUPSKI.PNG" class="rounded" alt="Cinque Terre" width="100%" height="500"></br>
    </div>
    
</div>