<div class="container-fluid">
        <div class="row">

                <?php foreach ($barang as $brg) : ?>

                <div class="card" style="width: 16rem">
                    <img src="<?php base_url().'/img/'.$brg->gambar ?>" class="card-img-top"  alt="">
                    
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $brg->nama_daftar ?></h5>
                        <p class="card-text"><?php echo $brg->keterangan ?></p>
                        <span class="badge badge-pill badge-success mb-3">Rp. <?php echo $brg->harga ?></span>
						<a class="btn btn-primary" href="<?= base_url('/seminar'); ?>">DAFTAR</a>
                      
                   
     
        </div>
        </div>
           <?php endforeach;?>
    </div>
</div>