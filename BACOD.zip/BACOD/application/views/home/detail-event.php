<div class="container-fluid">
	
	<div class="card">
		<h5 class="card-header">Deatai Event</h5>
		<div class="card-body">
		<?php foreach ($event as $event): ?>
			<div class="row">
				<div class="col-md-4">
					<tr><?php echo $event->judul_event?></tr>
					<br><img src="<?php echo base_url().'/assets/img/upload/'.$event->image ?>" class="card-img-top"  alt="" height="250" width="100">

				</div>
			<
			</div>
		<?php endforeach;?>
		</div>
	</div>
</div>