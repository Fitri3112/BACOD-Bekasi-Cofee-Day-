<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BEKASI COFFE DAY</title>
    <!-- CSS Bootstrap -->
    <link href="assets/vendor/sb-admin-2/css/sb-admin-2.min.css" rel="stylesheet">
    <!-- CSS kamu, Panggil CSS buatan mu sendiri di bawah sini seperti biasa -->
</head>

<body>
    <!-- Jumbotron -->
	
    <div class="container">
    <div class="bd-example mx-auto">
        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleCaptions" data-slide-to="3" class="active"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="3"></li>
                <li data-target="#carouselExampleCaptions" data-slide-to="3"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="assets/img/SEMINAR.jpg" class="d-block w-100%"  height="600" width="100%" alt="banner1">
                    
                </div>
                <div class="carousel-item">
                    <img src="assets/img/SEMINAR.png" class="d-block w-100%" height="600" width="100%" alt="banner2" >
                    
                </div>
                <div class="carousel-item">
                    <img src="assets/img/SEMINAR60.png" class="d-block w-100%" eight="600" width="100%" alt="banner3">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    </div>
	
    <div class="col text-left my-4">
                <h1> Pendaftaran</h1>
                <div class="dropdown"></div>
            </div>
    <div class="container-fluid ">
        <div class="row text-center">
        
                <?php foreach ($event as $event) : ?>
                <div class="col-md">
                <div class="card mr=4" style="width: 18rem" >
                    <img src="<?php echo base_url().'/assets/img/upload/'.$event->image ?>" class="card-img-top"  alt="" height="250" width="100">
                    
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $event->judul_event ?></h5>
                        <p class="card-text"><?php echo $event->keterangan ?></p>
                        <span class="badge badge-pill badge-success mb-3">Rp. <?php echo $event->harga ?></span>
						<br><a class="btn btn-sm btn btn-primary" href="<?= base_url('/seminar'); ?>">Booking Tiket</a>
                        <a class="btn btn-sm btn btn-success" href="<?= base_url('member/detailevent/' . $event->id); ?>">Detail</a>
                     </div>
                </div>
            </div>
     <?php endforeach;?>
            </div>
        </div>

   <div class="container-fluid">
        <div class="row">
            <div class="col text-left my-4">
                <h1> INFORMASI KAMI</h1>
                <div class="dropdown"></div>
            </div>
        </div>

     
    <div class="container-fluid ">
        <div class="row text-center">
        
                <?php foreach ($news as $news) : ?>
                <div class="col-md">
                <div class="card mr=4" style="width: 18rem" >
                    <img src="<?php echo base_url().'/assets/img/upload/'.$news->image ?>" class="card-img-top"  alt="" height="250" width="100">
                    
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $news->judul_news ?></h5>
                        
                        <p class="card-text"><?php echo $news->keterangan ?></p>
                      <h6 class="card-title"><?php echo $news->tanggal_input ?></h6>
                       
                        <a class="btn btn-sm btn btn-success" href="<?= base_url('member/detailnews/' . $news->id); ?>">Detail</a>
                     </div>
                </div>
            </div>
          <br>  
     <?php endforeach;?>
     <br>
            </div>
        </div>
    

    <!-- Controls, Ini adalah Panah Kanan dan Kiri. item ini dapat dihapus jika tidak diperlukan-->
    <a class="left carousel-control" href="#slideshow-mudah" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
    </a>
    <a class="right carousel-control" href="#slideshow-mudah" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
    </a>
    </div>
    <!-- Content END -->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>