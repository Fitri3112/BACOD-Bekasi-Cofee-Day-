<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>BEKASI COFFE DAY | <?= $judul; ?></title>
<link rel="icon" type="image/png" href="<?= base_url('assets/img/logo/'); ?>logo-pb.png">
  
<meta charset="utf-8">
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
<link rel="stylesheet" href="<?= base_url('assets/'); ?>css/prettyPhoto.css" type="text/css">
<link rel="stylesheet" href="<?= base_url('assets/'); ?>css/flexslider.css" type="text/css">
<link rel="stylesheet" href="<?= base_url('assets/'); ?>css/style.css" type="text/css">

<link rel="stylesheet" href="<?= base_url('assets/'); ?>css/sb-admin-2.min.css">
<link href="<?= base_url('assets/'); ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
<link href="<?= base_url('assets/'); ?>datatable/datatables.css" rel="stylesheet" type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--[if lt IE 9]>
<script src="js/html5.js"></script>
<script src="js/selectivizr-min.js"></script>
<link rel="stylesheet" href="css/ie.css" type="text/css">
<![endif]-->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/jquery.easing.1.3.js"></script>
<script src="assets/js/jquery-ui-1.8.16.custom.min.js"></script>
<script src="assets/js/all-in-one-min.js"></script>
<script src="assets/js/setup.js"></script>
<script>
$(window).load(function () {
    $('.flexslider').flexslider();
});

$(function () {
    $('#work').carouFredSel({
        width: '100%',
        scroll: 1,
        auto: false,
        pagination: false,
        prev: '.prev_item',
        next: '.next_item'
    });

    $("#work").touchwipe({
        wipeLeft: function () { $('.next_item').trigger('click'); },
        wipeRight: function () { $('.prev_item').trigger('click'); }
    });
});

$(window).load(function(){
	$('#demo-side-bar').removeAttr('style');
});
</script>
<style type="text/css">
.demobar {
	display:none;
}
#demo-side-bar {
	top:53px!important;
	left:90%!important;
	display:block!important;
}
</style>
</head>
<body>
<header class="header_bg clearfix">
  <div class="container clearfix">
    <!-- Social -->
    <ul class="social-links">
      <li><a href="#"><img src="assets/img/facebook.png" alt=""></a></li>
      <li><a href="#"><img src="assets/img/twitter.png" alt=""></a></li>
      <li><a href="#"><img src="assets/img/address.png" alt=""></a></li>
      <li><a href="#"><img src="assets/img/email.png" alt=""></a></li>
      <li><a href="#"><img src="assets/img/phone.png" alt=""></a></li>
     
    </ul>
    <!-- /Social -->
    <!-- Logo -->
    <div class="logo"> <a href="index.html"><img src="assets/img/logof.png" alt="" height="60" width="200"></a> </div>
    <!-- /Logo -->
    <!-- Master Nav -->
    <nav class="main-menu">
      <ul>
        
            <li><a href="<?= base_url(); ?>">Beranda <span class="sr-only">(current)</span></a></li>
            <li> <a>Event</a>
          <ul>
            <li><a href="<?= base_url('home/cara_pesan'); ?>">Cara Pesan <span class="sr-only">(current)</span></a></li>
            <li><a href="<?= base_url('/seponsor'); ?>">Seponsor <span class="sr-only">(current)</span></a></li>
            <li><a href="<?= base_url('home/cara_pesan'); ?>">Cara Pesan <span class="sr-only">(current)</span></a></li>
          </ul></li>
          <li> <a>Tentang Kami </a>
             <ul>
            <li><a href="<?= base_url('home/tentang_kami'); ?>">Kupski <span class="sr-only">(current)</span></a></li>
			     <li><a href="<?= base_url('/hubungi_kami'); ?>">Hubungi Kupski <span class="sr-only">(current)</span></a></li>
			     </ul></li>
			
			
	<?php if (!empty($this->session->userdata('email'))) { ?>
	 
			
			<li><a href="<?= base_url('member/myprofil'); ?>">Profil Saya</a></li>
         
		<li> <a>Pendaftaran</a>
          <ul>
            
            <li><a href="#">Seminar</a>
              <ul>
                <li><a href="<?= base_url('#'); ?>">Seminar Diskon</a></li>
                <li><a href="<?= base_url('/Seminar'); ?>">Seminar Ragular</a></li>
                
              </ul>
            </li>
			<li><a href="#">Competion</a>
              <ul>
                <li><a href="<?= base_url('#'); ?>">Competion Latte Art</a></li>
                <li><a href="<?= base_url('#'); ?>">Competion Manual Brewing</a></li>
                
              </ul>
            </li>
          </ul>
        </li>
      
        <li> <a>Transaksi</a>
          <ul>
            
                <li><a href="<?= base_url('home/Keranjang'); ?>">Keranjang</a></li>
                <li><a href="<?= base_url(''); ?>">Cetak Kartu</a></li>
                
              
          </ul></li>
        <li><a href="<?= base_url('member/logout'); ?>"><i class="fas fw fa-login"></i> Log out</a></li>
			<?php } else { ?>
		 <li><a href="#" data-toggle="modal" data-target="#daftarModal">Daftar Participant <span class="fas fw fa-login"></span></a></li>
    
		  <li> <a>Log in</a>
          <ul>
            
            <li><a href="<?= base_url('/home_admin'); ?>">Login Admin<span class="sr-only">(current)</span></a></li>
    <li><a class="nav-item nav-link" data-toggle="modal" data-target="#loginModal" href="#"><i class="fas fw fa-login"></i> Login Participant</a></li>
		</ul>
  </li>


    <?php } ?>
    <li><span class="nav-item nav-link navright" style="display:block; marginleft:80px; margin-right: :80px;">Selamat Datang <b><?= $user; ?></b></span></li>
      </ul>
    </nav>
    <!-- /Master Nav -->
  </div>
</header>
<!-- /Header -->
<!-- START CONTENT -->
<section class="container clearfix">
  <!-- Page Title -->
  <header class="container page_info clearfix">
    <h1 class="regular brown bottom_line"></h1>
    <div class="clear"></div>
  </header>
  <marquee> 
  <h3 class="regular brown bottom_line">Selamat Datang di Website Pendaftaran Bekasi Coffe Day "BACOD!"</h3>
  </marquee>
    <h4 class="regular brown bottom_line"></h4>
  <!-- /Page Title -->
