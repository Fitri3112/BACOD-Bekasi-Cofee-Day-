</div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-
q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="an
onymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.m
in.js" integrity="sha384-
UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="an
onymous"></script>
<script src="<?= base_url(); ?>assets/user/js/bootstrap.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.
js"></script>
<!-- Core plugin JavaScript-->
<script src="<?= base_url('assets/'); ?>vendor/jqueryeasing/jquery.easing.min.js"></script>
<!-- Custom scripts for all pages-->
<script src="<?= base_url('assets/'); ?>js/sb-admin-2.min.js"></script>
<script>
 $('.alert').alert().delay(3000).slideUp('slow');
 
</script>



<table>
<tr>
<td width="", height="100%"><img src="<?php echo base_url().'assets/img/'.$foto;?>"></td>
<td width="70%", height="100%">
			 <div class="modal-header">
				 <h1 class="modal-title">List Pendaftaran Seminar</h1>
				 
			 </div>
			
	<form >
				 <div class="modal-body">
		
        	<div class="container">
			<div class="row">
		

		<?php
			
			
foreach ($data->result_array() as $i) :
				$id=$i['id'];
				$nama=$i['nama'];
				$foto=$i['foto'];
				$alamat=$i['alamat'];
				$tgl=$i['tanggal_lahir'];
				$jk=$i['jk'];
				$pd=$i['pendidikan'];
				$tgli=$i['tanggal_input'];
				
		?>
		<div class="col-md-8 col-md-offset-2">
		<br></br>
			<h2><?php echo $nama;?></h2><hr/>
			<h5> Create by "<?php echo ucfirst($this->session->userdata('user')); ?>" :
			(<?php echo $tgli;?>)</h5><hr/>
								
			<img src="<?php echo base_url().'assets/images/'.$foto;?>">
			
			<?php echo limit_words($alamat,10);?>
			<div class="button intro_button">
			<a href="<?php echo base_url().'post_berita/viewadmin/'.$id;?>"> Read More</a>
			
			</div>
		</div>
		<?php endforeach;?>
	</div>
	</div>
    </form>
	
	 </div>
</div></td>
</tr>
</tr>
<td></td>
<td></td>
</table>

 
</body>
</html>