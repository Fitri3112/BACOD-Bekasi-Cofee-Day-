<div class="card text-center">
        <h1>SPONSOR RESMI KAMI</h1>
</div>

<div class="container-fluid">
    <img src="assets/img/sponsor1.PNG" class="rounded" alt="Cinque Terre" width="1330" height="500"></br>
    <div class="card text-center">
        <img src="assets/img/sponsor2.PNG" class="rounded" alt="Cinque Terre" width="1330" height="500"></br>
    </div>
    <div class="card text-center">
        <img src="assets/img/sponsor3.PNG" class="rounded" alt="Cinque Terre" width="1330" height="500"></br>
    </div>
    <div class="card text-center">
        <img src="assets/img/sponsor4.PNG" class="rounded" alt="Cinque Terre" width="1330" height="500"></br>
    </div>
    <div class="card text-center">
        <img src="assets/img/sponsor5.PNG" class="rounded" alt="Cinque Terre" width="1330" height="500"></br>
    </div>
    <div class="card text-center">
        <img src="assets/img/sponsor6.PNG" class="rounded" alt="Cinque Terre" width="1330" height="500"></br>
    </div>
</div>