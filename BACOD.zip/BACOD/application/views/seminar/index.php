<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Cache-Control" CONTENT="no-cache">
<title>IP CAMERA</title>
<link href="style/css.css" rel="stylesheet" type="text/css">
<SCRIPT language="JavaScript" src="ipcamera.js"></SCRIPT>
</head>
<body>
<IMG NAME="webcam" SRC="http://192.168.3.254:10001/jpg/image.jpg?1422104035771" BORDER=0/>
</body>
</html>
