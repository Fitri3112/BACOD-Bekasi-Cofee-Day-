var tick=0;
image=new Image();
reload = new Date();
reload = reload.getTime();
image.src="http://192.168.3.254:10001/jpg/image.jpg?"+reload;

function refreshCam()
{
tick++;
if(tick>3){restart=1;} else {restart=0;}
if(image.complete)
{
tick=0;
document.images["webcam"].src = image.src;
image=new Image();
reload = new Date();
reload = reload.getTime();
window.status = "";
image.src="http://192.168.3.254:10001/jpg/image.jpg?"+reload;
}
if(restart)
{
tick=0;
image=new Image();
reload = new Date();
reload = reload.getTime();
window.status = "";
image.src="http://192.168.3.254:10001/jpg/image.jpg?"+reload;
}
window.status = window.status + ".";
setTimeout("refreshCam()", 500);
}
refreshCam();