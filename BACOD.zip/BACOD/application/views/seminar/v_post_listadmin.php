<title>PUSTAKA PUISI</title>
<!-- Stylesheet -->
<link rel="shorcut icon" type="text/css" href="<?php echo base_url().'assets/images/logo.png'?>">

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="myHOME - real estate template project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/styles/bootstrap-4.1.2/bootstrap.min.css'?>">
<link href="<?php echo base_url().'assets/plugins/font-awesome-4.7.0/css/font-awesome.min.css'?> rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/plugins/OwlCarousel2-2.3.4/owl.carousel.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/plugins/OwlCarousel2-2.3.4/owl.theme.default.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/plugins/OwlCarousel2-2.3.4/animate.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/styles/main_styles.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/styles/responsive.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/styles/blog.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/styles/blog_responsive.css'?>">
</head>
<body>
		

	<!-- Menu -->

<div class="home">
		<div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="
		<?php echo base_url().'assets/images/about.jpg" data-speed="0.8'?>"></div>
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="home_content text-center">
						<div class="home_title">Event List</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="blog">
		<div class="container">
			<div class="row">
		

		<?php
			function limit_words($string, $word_limit){
                $words = explode(" ",$string);
                return implode(" ",array_splice($words,0,$word_limit));
            }
			
foreach ($data->result_array() as $i) :
				$id=$i['berita_id'];
				$judul=$i['berita_judul'];
				$image=$i['berita_image'];
				$isi=$i['berita_isi'];
				$tgl=$i['berita_tanggal'];
				
		?>
		<div class="col-md-8 col-md-offset-2">
		<br></br>
			<h2><?php echo $judul;?></h2><hr/>
			<h5> Create by "<?php echo ucfirst($this->session->userdata('username')); ?>" :
			(<?php echo $tgl;?>)</h5><hr/>
								
			<img src="<?php echo base_url().'assets/images/'.$image;?>">
			
			<?php echo limit_words($isi,10);?>
			<div class="button intro_button">
			<a href="<?php echo base_url().'post_berita/viewadmin/'.$id;?>"> Read More</a>
			
			</div>
		</div>
		<?php endforeach;?>
	</div>
	</div>
	</div>

	<script src="<?php echo base_url().'assets/jquery/jquery-2.2.3.min.js'?>"></script>
	<script type="text/javascript" src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
