</div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-
q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="an
onymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.m
in.js" integrity="sha384-
UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="an
onymous"></script>
<script src="<?= base_url(); ?>assets/user/js/bootstrap.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.
js"></script>
<!-- Core plugin JavaScript-->
<script src="<?= base_url('assets/'); ?>vendor/jqueryeasing/jquery.easing.min.js"></script>
<!-- Custom scripts for all pages-->
<script src="<?= base_url('assets/'); ?>js/sb-admin-2.min.js"></script>
<script>
 $('.alert').alert().delay(3000).slideUp('slow');
 
</script>
<img src="<?php echo base_url(); ?>assets/img/footer.png" style="display:grid;grid-template-columns:1fr;grid-template-rows:repeat(auto-fill, minmax(100px, 1fr));", class="d-block w-100%" height="2%" width="100%">

<div class="container-fluid  fixed-bottom bg-light" ;>
			
					<b><i><p align="center" >Copyright &copy; KUPSKI <?= date('Y'); ?></p></i></b>
</div>


</body>
</html>