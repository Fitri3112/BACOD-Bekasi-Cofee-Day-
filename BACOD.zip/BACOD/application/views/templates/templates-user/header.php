<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BEKASI COFFE DAY | <?= $judul; ?></title>
	<link rel="icon" type="image/png" href="<?= base_url('assets/img/logo/'); ?>logo-pb.png">
	
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/sb-admin-2.min.css">
	<link href="<?= base_url('assets/'); ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link href="<?= base_url('assets/'); ?>datatable/datatables.css" rel="stylesheet" type="text/css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<style>



.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}


</style>
</head>

<body>
<link rel="shorcut icon" type="text/css" href="<?php echo base_url().'assets/images/logo.png'?>">

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="myHOME - real estate template project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/styles/bootstrap-4.1.2/bootstrap.min.css'?>">
<link href="<?php echo base_url().'assets/plugins/font-awesome-4.7.0/css/font-awesome.min.css'?> rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/plugins/OwlCarousel2-2.3.4/owl.carousel.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/plugins/OwlCarousel2-2.3.4/owl.theme.default.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/plugins/OwlCarousel2-2.3.4/animate.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/styles/main_styles.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/styles/responsive.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/styles/about.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/styles/about_responsive.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/styles/blog.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/styles/blog_responsive.css'?>">

</head>
<body>

 <nav class="navbar navbar-expand-lg navbar-light bg-light">
	 <div class="container">
	 <a class="navbar-brand" href="<?= base_url(); ?>">BACOD</a>
	 
	 <button class="navbar-toggler" type="button" datatoggle="collapse" data-target="#navbarNavAltMarkup" ariacontrols="navbarNavAltMarkup" 
	 aria-expanded="false" arialabel="Toggle navigation">
	 <span class="navbar-toggler-icon"></span>
	 </button>
	 
	 <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
	 <div class="navbar-nav">
	 <a class="nav-item nav-link active" href="<?= base_url(); ?>">Beranda <span class="sr-only">(current)</span></a>
	 <a class="nav-item nav-link active" href="<?= base_url('/seponsor'); ?>">Seponsor <span class="sr-only">(current)</span></a>
	 <a class="nav-item nav-link active" href="<?= base_url(); ?>">News <span class="sr-only">(current)</span></a>
	 <a class="nav-item nav-link active" href="<?= base_url('hubungi_kami/hubungi_kami'); ?>">Hubungi Kami <span class="sr-only">(current)</span></a>
		<?php if (!empty($this->session->userdata('email'))) { ?>
	 
	 <a class="nav-item nav-link" href="<?= base_url('member/myprofil'); ?>">Profil Saya</a>
	 <a class="nav-item nav-link" href="<?= base_url(''); ?>">Pembayaran</a>
	  <div class="dropdown" >
	  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
       Pendaftaran
       </a>
	  <div class="dropdown-content">
		<a href="<?= base_url('/seminar'); ?>">Seminar</a>
		
		<a href="#">Competion Latte Art</a>
		<a href="#">Competion Manual Brewing</a>
	  </div>
	
	</div>
	 <a class="nav-item nav-link" href="<?= base_url('member/logout'); ?>"><i class="fas fw fa-login"></i> Log out</a> 
		
		<?php } else { ?>
		
	 <a class="nav-item nav-link" data-toggle="modal" data-target="#daftarModal" href="#"><i class="fas fw fa-login"></i> Daftar</a>
	 <a class="nav-item nav-link" data-toggle="modal" data-target="#loginModal" href="#"><i class="fas fw fa-login"></i> Log in</a>
	 
	
		<?php } ?>
 
	 <span class="nav-item nav-link navright" style="display:block; marginleft:20px;">Selamat Datang <b><?= $user; ?></b></span>
	 </div>
	 </div>
	 </div>
 
 </nav>

 <div class="container mt-5">
